import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { fireEvent, render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from '../src/App'

beforeEach(() => {
  localStorage.clear()
  vi.stubGlobal('fetch', vi.fn(async () =>
    ({ ok: false, status: 501, json: async () => ({ error: 'provider_not_configured' }) })))
})
afterEach(() => vi.unstubAllGlobals())

describe('Composer', () => {
  it('Enter mengirim pesan; textarea dikosongkan', async () => {
    const user = userEvent.setup()
    render(<App />)
    const ta = screen.getByLabelText(/pesan untuk dudu/i) as HTMLTextAreaElement
    await user.type(ta, 'Halo Dudu')
    await user.keyboard('{Enter}')
    expect(
  await screen.findByText('Halo Dudu', {
    selector: '.msg-row.user .msg-text',
  })
).toBeInTheDocument()
    
    expect(ta.value).toBe('')
  })

  it('Shift+Enter menyisipkan baris baru tanpa mengirim', async () => {
    const user = userEvent.setup()
    const { container } = render(<App />)
    const ta = screen.getByLabelText(/pesan untuk dudu/i) as HTMLTextAreaElement
    await user.type(ta, 'baris1{Shift>}{Enter}{/Shift}baris2')
    expect(ta.value).toBe('baris1\nbaris2')
    expect(container.querySelector('.msg-row.user')).toBeNull()
  })

  it('IME-safe: Enter saat composition tidak mengirim', async () => {
  render(<App />)
  const ta = screen.getByLabelText(/pesan untuk dudu/i) as HTMLTextAreaElement

  fireEvent.change(ta, { target: { value: 'nihongo' } })
  fireEvent.compositionStart(ta)
  fireEvent.keyDown(ta, { key: 'Enter' })

  // Saat komposisi berlangsung, teks harus tetap di input.
  expect(ta.value).toBe('nihongo')
})

  it('provider 501 → pesan error jujur + tombol Coba lagi, tanpa respons palsu', async () => {
    const user = userEvent.setup()
    render(<App />)
    const ta = screen.getByLabelText(/pesan untuk dudu/i)
    await user.type(ta, 'Uji provider')
    await user.keyboard('{Enter}')
    expect(await screen.findByText(/DUDU_PROVIDER_API_KEY/)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /coba lagi/i })).toBeInTheDocument()
  })
})
