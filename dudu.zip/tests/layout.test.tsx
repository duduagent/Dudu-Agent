import { beforeEach, describe, expect, it } from 'vitest'
import { fireEvent, render, screen } from '@testing-library/react'
import App from '../src/App'

beforeEach(() => { localStorage.clear() })

const appEl = (c: HTMLElement) => c.querySelector('.app') as HTMLElement

describe('Layout tiga region', () => {
  it('sidebar kiri dan kanan collapse secara independen', () => {
    const { container } = render(<App />)
    const app = appEl(container)
    expect(app.className).not.toContain('left-collapsed')
    expect(app.className).not.toContain('right-collapsed')

    fireEvent.click(screen.getByRole('button', { name: 'Menu utama' }))
    expect(app.className).toContain('left-collapsed')
    expect(app.className).not.toContain('right-collapsed')

    fireEvent.click(screen.getByRole('button', { name: 'Panel konteks' }))
    expect(app.className).toContain('right-collapsed')
  })

  it('kedua sidebar bisa tertutup bersamaan (center melebar via flex 1fr)', () => {
    const { container } = render(<App />)
    const app = appEl(container)
    fireEvent.click(screen.getByRole('button', { name: 'Menu utama' }))
    fireEvent.click(screen.getByRole('button', { name: 'Panel konteks' }))
    expect(app.className).toContain('left-collapsed')
    expect(app.className).toContain('right-collapsed')
    // Verifikasi piksel nyata butuh browser — lihat checklist manual di README.
  })

  it('preferensi collapse dipersistenkan ke localStorage', () => {
    render(<App />)
    fireEvent.click(screen.getByRole('button', { name: 'Menu utama' }))
    fireEvent.click(screen.getByRole('button', { name: 'Panel konteks' }))
    const prefs = JSON.parse(localStorage.getItem('dudu.prefs.v1') ?? '{}')
    expect(prefs.leftCollapsed).toBe(true)
    expect(prefs.rightCollapsed).toBe(true)
  })
})
