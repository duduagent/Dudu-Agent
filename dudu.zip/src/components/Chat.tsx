import { useEffect, useRef, useState, type KeyboardEvent as ReactKeyboardEvent, type ReactNode } from 'react'
import { ProviderNotConfigured, sendChat } from '../lib/provider'
import type { Conversation, Message, ProviderInfo, Role } from '../lib/types'
import { cx, timeAgo } from '../lib/util'
import { DuduMark, Icon } from './ui'

const SYSTEM_PROMPT =
  'Kamu adalah Dudu, asisten AI pribadi untuk perencanaan, analisis, dan eksekusi tugas. ' +
  'Jawab dalam bahasa Indonesia secara ringkas, jelas, dan terstruktur menggunakan Markdown standar. ' +
  'Jangan menulis tag HTML seperti <br>, <div>, atau <p> sebagai teks. ' +
  'Gunakan baris baru untuk memisahkan paragraf. ' +
  'Untuk tabel, gunakan Markdown standar: setiap baris pada baris tersendiri, sertakan pemisah | --- | --- |, dan gunakan tanda | untuk memisahkan kolom. ' +
  'Jika tabel tidak diperlukan, gunakan judul dan daftar berpoin. ' +
  'Jangan mengklaim kemampuan atau status yang belum benar-benar tersedia.'

const MAX_CHARS = 8000
type ChatMsg = { role: Role; content: string }

const STARTERS = [
  'Rangkum tujuan proyek saya dan susun rencana kerja',
  'Buat checklist peluncuran produk minggu ini',
  'Jelaskan arsitektur aplikasi ini dengan bahasa sederhana',
  'Buat draft email follow-up ke klien',
]

interface Props {
  conv: Conversation | null
  leftCollapsed: boolean
  rightCollapsed: boolean
  onToggleLeft: () => void
  onToggleRight: () => void
  onCreateConversation: () => string
  onAddMessage: (convId: string, msg: { role: Role; content: string; status?: Message['status'] }) => string
  onUpdateMessage: (convId: string, msgId: string, patch: Partial<Message>) => void
  onDeleteMessage: (convId: string, msgId: string) => void
  onActivity: (msg: string) => void
}

export function ChatWorkspace(props: Props) {
  const { conv, onCreateConversation, onAddMessage, onUpdateMessage, onDeleteMessage, onActivity } = props
  const [composer, setComposer] = useState('')
  const [streaming, setStreaming] = useState(false)
  const [provider, setProvider] = useState<ProviderInfo>({ state: 'unknown' })
  const abortRef = useRef<AbortController | null>(null)
  const taRef = useRef<HTMLTextAreaElement | null>(null)
  const endRef = useRef<HTMLDivElement | null>(null)
  const composingRef = useRef(false)

  // Health check nyata saat mount — pill status mencerminkan kondisi server, bukan angan-angan.
  useEffect(() => {
    let alive = true
    fetch('/api/health')
      .then(r => r.json())
      .then((d: { configured?: boolean }) => {
        if (!alive) return
        setProvider(p => p.state === 'unknown' && !d.configured
          ? { state: 'unconfigured', detail: 'Server berjalan tanpa kredensial provider.' } : p)
      })
      .catch(() => {
        if (alive) setProvider(p => p.state === 'unknown'
          ? { state: 'unconfigured', detail: 'Server API tidak terjangkau — jalankan `npm run server`.' } : p)
      })
    return () => { alive = false }
  }, [])

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }) }, [conv?.messages.length, streaming])

  useEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 220) + 'px'
  }, [composer])

  function historyFrom(messages: Message[], extraUser?: string): ChatMsg[] {
    const base = messages.filter(m => m.status !== 'error' && m.content).slice(-20)
      .map(m => ({ role: m.role, content: m.content }))
    const hist: ChatMsg[] = [{ role: 'system', content: SYSTEM_PROMPT }, ...base]
    if (extraUser) hist.push({ role: 'user', content: extraUser })
    return hist
  }

  async function runGeneration(convId: string, history: ChatMsg[]) {
    const aiId = onAddMessage(convId, { role: 'assistant', content: '', status: 'sending' })
    const ac = new AbortController()
    abortRef.current = ac
    setStreaming(true)
    try {
      const reply = await sendChat(history, ac.signal)
      onUpdateMessage(convId, aiId, { content: reply.content, status: 'done' })
      setProvider({ state: 'ok', model: reply.model })
      onActivity(reply.model ? `Respons diterima (${reply.model})` : 'Respons diterima')
    } catch (err) {
      if ((err as Error).name === 'AbortError') {
        onDeleteMessage(convId, aiId)
        onActivity('Pembuatan respons dihentikan')
      } else if (err instanceof ProviderNotConfigured) {
        onUpdateMessage(convId, aiId, { status: 'error', error: err.message })
        setProvider({ state: 'unconfigured', detail: err.message })
        onActivity('Provider belum dikonfigurasi')
      } else {
        const msg = err instanceof Error ? err.message : 'Kesalahan tak diketahui'
        onUpdateMessage(convId, aiId, { status: 'error', error: msg })
        setProvider({ state: 'error', detail: msg })
        onActivity('Gagal memanggil provider')
      }
    } finally {
      setStreaming(false)
      abortRef.current = null
    }
  }

  async function sendText(text: string) {
    const trimmed = text.trim()
    if (!trimmed || streaming || trimmed.length > MAX_CHARS) return
    setComposer('')
    const convId = conv?.id ?? onCreateConversation()
    const history = historyFrom(conv?.messages ?? [], trimmed)
    onAddMessage(convId, { role: 'user', content: trimmed, status: 'done' })
    onActivity('Pesan dikirim')
    await runGeneration(convId, history)
  }

  function retryAssistant(msgId: string) {
    if (!conv || streaming) return
    onDeleteMessage(conv.id, msgId)
    onActivity('Respons dicoba ulang')
    void runGeneration(conv.id, historyFrom(conv.messages))
  }

  function onKeyDown(e: ReactKeyboardEvent<HTMLTextAreaElement>) {
    if (e.key !== 'Enter' || e.shiftKey) return
    if (e.nativeEvent.isComposing || composingRef.current) return  // IME-safe
    e.preventDefault()
    void sendText(composer)
  }

  const pill =
    provider.state === 'ok' ? { cls: 'ok', label: `Terhubung${provider.model ? ` · ${provider.model}` : ''}` } :
    provider.state === 'unconfigured' ? { cls: 'warn', label: 'Provider belum dikonfigurasi' } :
    provider.state === 'error' ? { cls: 'err', label: 'Provider error' } :
    { cls: '', label: 'Provider: belum diverifikasi' }

  const hasMessages = !!conv && conv.messages.length > 0

  return (
    <>
      <header className="chat-header">
        <div className="header-left">
          <button type="button" className="icon-btn" onClick={props.onToggleLeft}
            aria-expanded={!props.leftCollapsed} aria-controls="left-sidebar"
            title={props.leftCollapsed ? 'Buka sidebar kiri' : 'Tutup sidebar kiri'}>
            <Icon name="menu" size={18} />
            <span className="sr-only">Menu utama</span>
          </button>
          <div className="header-title">
            <strong>{conv?.title ?? 'Chat Baru'}</strong>
            <span className={cx('pill', pill.cls)}>{pill.label}</span>
          </div>
        </div>
        <button type="button" className="icon-btn" onClick={props.onToggleRight}
          aria-expanded={!props.rightCollapsed} aria-controls="right-sidebar"
          title={props.rightCollapsed ? 'Buka panel konteks' : 'Tutup panel konteks'}>
          <Icon name="panel" size={18} />
          <span className="sr-only">Panel konteks</span>
        </button>
      </header>

      {!hasMessages ? (
        <div className="welcome">
          <DuduMark size={96} />
          <h1>Halo! Saya Dudu.</h1>
          <p className="sub">Apa yang ingin kita selesaikan hari ini?</p>
          <div className="starters">
            {STARTERS.map(s => (
              <button type="button" key={s} className="starter"
                onClick={() => { setComposer(s); taRef.current?.focus() }}>{s}</button>
            ))}
          </div>
          {provider.state !== 'ok' && (
            <p className="local-note">
              Mode lokal: percakapan tersimpan di browser ini (bukan cloud), dan respons model belum aktif
              sampai provider dikonfigurasi (DUDU_PROVIDER_API_KEY di server). Tidak ada respons palsu yang ditampilkan.
            </p>
          )}
        </div>
      ) : (
        <div className="chat-scroll">
          <div className="chat-col">
            {conv!.messages.map(m => (
              <MessageRow key={m.id} msg={m} onRetry={() => retryAssistant(m.id)} />
            ))}
            <div ref={endRef} />
          </div>
        </div>
      )}

      <div className="composer-zone">
        <div className="composer-box">
          <textarea id="composer" ref={taRef} value={composer} rows={1}
            onChange={e => setComposer(e.target.value.slice(0, MAX_CHARS))}
            onKeyDown={onKeyDown}
            onCompositionStart={() => { composingRef.current = true }}
            onCompositionEnd={() => { composingRef.current = false }}
            placeholder="Tulis pesan untuk Dudu…"
            aria-label="Pesan untuk Dudu"
            maxLength={MAX_CHARS} />
          <div className="composer-tools">
            <button type="button" className="icon-btn" disabled
              title="Voice direncanakan untuk Milestone E — belum diimplementasikan">
              <Icon name="mic" size={17} />
              <span className="sr-only">Voice (belum aktif)</span>
            </button>
            {streaming ? (
              <button type="button" className="btn-stop" onClick={() => abortRef.current?.abort()}>
                <Icon name="stop" size={14} /> Hentikan
              </button>
            ) : (
              <button type="button" className="btn-send" onClick={() => void sendText(composer)}
                disabled={!composer.trim()} title="Kirim (Enter)">
                <Icon name="send" size={16} />
                <span className="sr-only">Kirim pesan</span>
              </button>
            )}
          </div>
        </div>
        <div className="composer-foot">
          <span>Enter untuk kirim · Shift+Enter baris baru</span>
          {composer.length > 7000 && (
            <span className={cx('char-count', composer.length >= MAX_CHARS && 'over')}>
              {composer.length}/{MAX_CHARS}
            </span>
          )}
        </div>
      </div>
    </>
  )
}

/* ---------- Pesan & Markdown minimal ---------- */

function MessageRow({ msg, onRetry }: { msg: Message; onRetry: () => void }) {
  const [copied, setCopied] = useState(false)

  async function copy() {
    try {
      await navigator.clipboard.writeText(msg.content)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    } catch { /* clipboard tidak tersedia di lingkungan ini */ }
  }

  if (msg.role === 'user') {
    return (
      <div className="msg-row user">
        <div className="msg user-msg">
          <div className="msg-text">{renderContent(msg.content)}</div>
          <div className="msg-meta">{timeAgo(msg.createdAt)}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="msg-row assistant">
      <DuduMark size={28} />
      <div className="msg assistant-msg">
        {msg.status === 'sending' ? (
          <div className="typing" role="status" aria-label="Dudu sedang mengetik"><span /><span /><span /></div>
        ) : msg.status === 'error' ? (
          <div className="msg-error" role="alert">
            <Icon name="alert" size={15} />
            <span>{msg.error}</span>
            <button type="button" className="link-btn" onClick={onRetry}>
              <Icon name="retry" size={13} /> Coba lagi
            </button>
          </div>
        ) : (
          <>
            <div className="msg-text">{renderContent(msg.content)}</div>
            {msg.content && (
              <div className="msg-actions">
                <button type="button" className="chip-btn" onClick={copy}>
                  <Icon name="copy" size={13} /> {copied ? 'Tersalin' : 'Salin'}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function inlineTokens(text: string, keyBase: string): ReactNode[] {
  const out: ReactNode[] = []
  const re =
    /(\*\*[^\*\n]+\*\*|\*[^\*\n]+\*|`[^`\n]+`|https?:\/\/[^\s)]+)/g

  let last = 0
  let match: RegExpExecArray | null
  let i = 0

  while ((match = re.exec(text)) !== null) {
    if (match.index > last) {
      out.push(text.slice(last, match.index))
    }

    const token = match[0]
    const key = `${keyBase}-${i++}`

    if (token.startsWith('**') && token.endsWith('**')) {
      out.push(
        <strong key={key}>{token.slice(2, -2)}</strong>
      )
    } else if (token.startsWith('*') && token.endsWith('*')) {
      out.push(
        <em key={key}>{token.slice(1, -1)}</em>
      )
    } else if (token.startsWith('`')) {
      out.push(
        <code key={key} className="inline-code">
          {token.slice(1, -1)}
        </code>
      )
    } else {
      out.push(
        <a
          key={key}
          href={token}
          target="_blank"
          rel="noreferrer"
        >
          {token}
        </a>
      )
    }

    last = match.index + token.length
  }

  if (last < text.length) {
    out.push(text.slice(last))
  }

  return out
}

function TextBlock({ text, k }: { text: string; k: string }) {
  const nodes: ReactNode[] = []
  const lines = text.split('\n')
  let paragraph: string[] = []
  let list: string[] = []
  let i = 0

  const flushParagraph = () => {
    if (!paragraph.length) return

    const content = paragraph.join(' ').trim()

    if (content) {
      nodes.push(
        <p key={`${k}-p${i++}`}>
          {inlineTokens(content, `${k}-inline${i}`)}
        </p>
      )
    }

    paragraph = []
  }

  const flushList = () => {
    if (!list.length) return

    nodes.push(
      <ul key={`${k}-ul${i++}`}>
        {list.map((item, index) => (
          <li key={index}>
            {inlineTokens(item, `${k}-li${i}-${index}`)}
          </li>
        ))}
      </ul>
    )

    list = []
  }

  const isTableRow = (line: string) =>
    line.includes('|') &&
    line.trim().split('|').length >= 3

const parseCells = (line: string): string[] =>
  line
    .trim()
    .replace(/^\|/, '')
    .replace(/\|$/, '')
    .split('|')
    .map(cell => cell.trim())

const isSeparatorRow = (line: string): boolean => {
  const cells = parseCells(line)
  return (
    cells.length >= 2 &&
    cells.every(cell => /^:?-{3,}:?$/.test(cell))
  )
}

  while (i < lines.length) {
    const line = lines[i].trim()

    // Tabel Markdown: baris judul diikuti baris pemisah.
    if (
      isTableRow(line) &&
      i + 1 < lines.length &&
      isTableRow(lines[i + 1].trim()) &&
      isSeparatorRow(lines[i + 1].trim())
    ) {
      flushParagraph()
      flushList()

      const headers = parseCells(line)
      i += 2

      const rows: string[][] = []

      while (
        i < lines.length &&
        isTableRow(lines[i].trim()) &&
        !isSeparatorRow(lines[i].trim())
      ) {
        rows.push(parseCells(lines[i]))
        i++
      }

      nodes.push(
        <div className="markdown-table-wrap" key={`${k}-table${i}`}>
          <table className="markdown-table">
            <thead>
              <tr>
                {headers.map((cell, index) => (
                  <th key={index}>
                    {inlineTokens(cell, `${k}-th${index}`)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {headers.map((_, colIndex) => (
                    <td key={colIndex}>
                      {inlineTokens(
                        row[colIndex] ?? '',
                        `${k}-td${rowIndex}-${colIndex}`
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )

      continue
    }

    // Judul Markdown.
    const heading = line.match(/^(#{1,3})\s+(.+)$/)

    if (heading) {
      flushParagraph()
      flushList()

      const level = heading[1].length
      const content = inlineTokens(
        heading[2],
        `${k}-heading${i}`
      )

      if (level === 1) {
        nodes.push(<h2 key={`${k}-h${i}`}>{content}</h2>)
      } else if (level === 2) {
        nodes.push(<h3 key={`${k}-h${i}`}>{content}</h3>)
      } else {
        nodes.push(<h4 key={`${k}-h${i}`}>{content}</h4>)
      }

      i++
      continue
    }

    // Daftar berpoin.
    const bullet = line.match(/^[-*]\s+(.+)$/)

    if (bullet) {
      flushParagraph()
      list.push(bullet[1])
      i++
      continue
    }

    // Daftar bernomor.
    const numbered = line.match(/^\d+[.)]\s+(.+)$/)

    if (numbered) {
      flushParagraph()
      list.push(numbered[1])
      i++
      continue
    }

    if (!line) {
      flushParagraph()
      flushList()
      i++
      continue
    }

    flushList()
    paragraph.push(line)
    i++
  }

  flushParagraph()
  flushList()

  return <>{nodes}</>
}

function renderContent(content: string): ReactNode {
  if (!content) return null

  const normalized = content
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/&lt;br\s*\/?&gt;/gi, '\n')
    .replace(/\r\n?/g, '\n')

  return (
    <>
      {normalized.split('```').map((part, index) => {
        if (index % 2 === 1) {
          const newline = part.indexOf('\n')
          const language =
            newline > -1 ? part.slice(0, newline).trim() : ''
          const code =
            newline > -1 ? part.slice(newline + 1) : part

          return (
            <pre
              key={index}
              className="code-block"
              tabIndex={0}
            >
              {language && (
                <span className="code-lang">{language}</span>
              )}
              <code>{code.replace(/\n+$/, '')}</code>
            </pre>
          )
        }

        return (
          <TextBlock
            key={index}
            text={part}
            k={`block${index}`}
          />
        )
      })}
    </>
  )
}
