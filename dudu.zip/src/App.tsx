import { useEffect, useState } from 'react'
import { ChatWorkspace } from './components/Chat'
import { SidebarLeft, SidebarRight } from './components/Sidebars'
import { Icon } from './components/ui'
import { ReminderWorkspace } from './components/ReminderWorkspace'
import { useActivity, useConversations, useIsMobile, usePrefs } from './lib/hooks'
import type { ViewId } from './lib/types'
import { cx } from './lib/util'

const PLACEHOLDER_INFO: Record<Exclude<ViewId, 'chat'>, { title: string; milestone: string; desc: string }> = {
  missions: { title: 'Misi & Tugas', milestone: 'Milestone F', desc: 'Siklus misi lengkap: kriteria penerimaan, persetujuan, eksekusi, verifikasi, dan artefak.' },
  workforce: { title: 'Agent Workforce', milestone: 'Milestone F', desc: 'Adapter coding-agent nyata dengan batas izin, status koneksi sebenarnya, dan log eksekusi.' },
  knowledge: { title: 'Knowledge Base', milestone: 'Belum dijadwalkan', desc: 'Basis pengetahuan pribadi dengan sumber terverifikasi.' },
  tools: { title: 'Tools & Integrations', milestone: 'Milestone F+', desc: 'Registri adapter tool dengan health check nyata — tanpa status palsu.' },
  files: { title: 'Files & Artifacts', milestone: 'Milestone F', desc: 'File, artefak, dan bukti eksekusi yang terkait misi.' },
  memory: { title: 'Memory', milestone: 'Belum dijadwalkan', desc: 'Memori jangka panjang dengan kontrol eksplisit.' },
  settings: { title: 'Pengaturan', milestone: 'Milestone C+', desc: 'Preferensi tampilan, provider, dan penyimpanan.' },
}

function PlaceholderView({ view, onBack }: { view: Exclude<ViewId, 'chat'>; onBack: () => void }) {
  const info = PLACEHOLDER_INFO[view]
  return (
    <div className="placeholder">
      <div className="placeholder-card">
        <span className="badge">{info.milestone}</span>
        <h2>{info.title}</h2>
        <p>{info.desc}</p>
        <p className="empty-note">Modul ini belum diimplementasikan. Tidak ada data simulasi yang ditampilkan untuk modul ini.</p>
        <button type="button" className="link-btn" onClick={onBack}>
          <Icon name="back" size={14} /> Kembali ke Chat
        </button>
      </div>
    </div>
  )
}

export default function App() {
  const isMobile = useIsMobile()
  const [prefs, setPrefs] = usePrefs(
    isMobile ? { leftCollapsed: true, rightCollapsed: true } : { leftCollapsed: false, rightCollapsed: false },
  )
  const conversations = useConversations()
  const [events, pushEvent] = useActivity()
  const [view, setView] = useState<ViewId>('chat')

  const activeConv = conversations.conversations.find(c => c.id === conversations.activeId) ?? null

  useEffect(() => {
    if (!isMobile) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPrefs({ leftCollapsed: true, rightCollapsed: true })
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [isMobile, setPrefs])

  const appCls = cx(
    'app',
    prefs.leftCollapsed && 'left-collapsed',
    prefs.rightCollapsed && 'right-collapsed',
    isMobile && (!prefs.leftCollapsed || !prefs.rightCollapsed) && 'has-overlay',
  )

  return (
    <div className={appCls}>
      <a className="skip-link" href="#composer">Langsung ke composer</a>
      <SidebarLeft
        collapsed={prefs.leftCollapsed}
        onToggle={() => setPrefs({ leftCollapsed: !prefs.leftCollapsed })}
        view={view}
        onSelectView={setView}
        conversations={conversations.conversations}
        activeId={conversations.activeId}
        onSelectConversation={id => { conversations.select(id); setView('chat') }}
        onNewChat={() => { conversations.select(null); setView('chat'); pushEvent('Chat baru dimulai') }}
        onRename={conversations.rename}
        onDelete={id => { conversations.remove(id); pushEvent('Percakapan dihapus') }}
      />
      <div className="scrim" onClick={() => setPrefs({ leftCollapsed: true, rightCollapsed: true })} aria-hidden="true" />
      <main className="center" id="main">
        {view === 'chat' ? (
          <ChatWorkspace
            conv={activeConv}
            leftCollapsed={prefs.leftCollapsed}
            rightCollapsed={prefs.rightCollapsed}
            onToggleLeft={() => setPrefs({ leftCollapsed: !prefs.leftCollapsed })}
            onToggleRight={() => setPrefs({ rightCollapsed: !prefs.rightCollapsed })}
            onCreateConversation={() => {
              const id = conversations.create()
              pushEvent('Percakapan dibuat')
              return id
            }}
            onAddMessage={conversations.addMessage}
            onUpdateMessage={conversations.updateMessage}
            onDeleteMessage={conversations.deleteMessage}
            onActivity={pushEvent}
          />
        ) : view === 'missions' ? (
          <ReminderWorkspace onActivity={pushEvent} />
        ) : (
          <PlaceholderView view={view} onBack={() => setView('chat')} />
        )}
      </main>
      <SidebarRight
        collapsed={prefs.rightCollapsed}
        onToggle={() => setPrefs({ rightCollapsed: !prefs.rightCollapsed })}
        events={events}
      />
    </div>
  )
}
