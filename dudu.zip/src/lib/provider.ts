import type { Role } from './types'

export class ProviderNotConfigured extends Error {}

export interface ProviderReply { content: string; model?: string }

export async function sendChat(
  messages: Array<{ role: Role; content: string }>,
  signal?: AbortSignal,
): Promise<ProviderReply> {
  let res: Response
  try {
    res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages }),
      signal,
    })
  } catch (err) {
    if ((err as Error).name === 'AbortError') throw err
    throw new ProviderNotConfigured('Server API tidak terjangkau. Jalankan `npm run server`, lalu coba lagi.')
  }
  if (res.status === 501) {
    throw new ProviderNotConfigured('Provider model belum dikonfigurasi (butuh DUDU_PROVIDER_API_KEY di server).')
  }
  if (!res.ok) throw new Error(`Provider merespons ${res.status}.`)
  const data = (await res.json()) as { content?: unknown; model?: unknown }
  if (typeof data.content !== 'string') throw new Error('Format respons provider tidak valid.')
  return { content: data.content, model: typeof data.model === 'string' ? data.model : undefined }
}
