import type { Conversation, Prefs } from './types'

const CONV_KEY = 'dudu.conversations.v1'
const ACTIVE_KEY = 'dudu.activeConversation.v1'
const PREFS_KEY = 'dudu.prefs.v1'

// BATASAN EKSPLISIT: ini penyimpanan LOKAL di browser, bukan cloud storage.
export const STORAGE_NOTICE = 'Data lokal di browser ini — bukan cloud.'

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

function write(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch { /* kuota penuh / private mode */ }
}

export const loadConversations = () => read<Conversation[]>(CONV_KEY, [])
export const saveConversations = (c: Conversation[]) => write(CONV_KEY, c)
export const loadActiveId = () => read<string | null>(ACTIVE_KEY, null)
export const saveActiveId = (id: string | null) => write(ACTIVE_KEY, id)

export function loadPrefs(): Prefs | null {
  try {
    const raw = localStorage.getItem(PREFS_KEY)
    return raw ? (JSON.parse(raw) as Prefs) : null
  } catch { return null }
}
export const savePrefs = (p: Prefs) => write(PREFS_KEY, p)
