import http from 'node:http'

const PORT = Number(process.env.PORT || 8787)
const API_KEY = process.env.DUDU_PROVIDER_API_KEY
const BASE_URL = (
  process.env.DUDU_PROVIDER_BASE_URL ||
  'https://open.bigmodel.cn/api/paas/v4'
).replace(/\/+$/, '')
const MODEL = process.env.DUDU_MODEL || 'glm-4-flash'

const json = (res, code, obj) => {
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
  })
  res.end(JSON.stringify(obj))
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/api/health') {
    return json(res, 200, {
      configured: Boolean(API_KEY),
      model: MODEL,
    })
  }

  if (req.method !== 'POST' || req.url !== '/api/chat') {
    return json(res, 404, { error: 'not_found' })
  }

  let body = ''

  req.on('data', (chunk) => {
    body += chunk

    if (body.length > 256_000) {
      json(res, 413, { error: 'request_too_large' })
      req.destroy()
    }
  })

  req.on('end', async () => {
    if (res.writableEnded) return

    if (!API_KEY) {
      return json(res, 501, {
        error: 'provider_not_configured',
        message: 'Set DUDU_PROVIDER_API_KEY in .env.',
      })
    }

    let messages

    try {
      ({ messages } = JSON.parse(body))
    } catch {
      return json(res, 400, { error: 'bad_json' })
    }

    if (
      !Array.isArray(messages) ||
      messages.length === 0 ||
      !messages.every(
        (m) =>
          m &&
          typeof m.role === 'string' &&
          ['system', 'user', 'assistant'].includes(m.role)
      )
    ) {
      return json(res, 400, { error: 'bad_request' })
    }

    const payload = JSON.stringify({
      model: MODEL,
      messages: messages.map((m) => ({
        role: m.role,
        content: String(m.content ?? '').slice(0, 32_000),
      })),
    })

    try {
      const upstream = await fetch(
        `${BASE_URL}/chat/completions`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${API_KEY}`,
          },
          body: payload,
          signal: AbortSignal.timeout(30_000),
        }
      )

      const responseText = await upstream.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        console.error(
          `[chat] invalid JSON from provider; status=${upstream.status}`
        )

        return json(res, 502, {
          error: 'bad_upstream_response',
          status: upstream.status,
          details: 'Provider returned a non-JSON response.',
        })
      }

      if (!upstream.ok) {
        const details =
          data?.error?.message ||
          data?.message ||
          'Provider request failed.'

        console.error(
          `[chat] upstream error status=${upstream.status}: ${details}`
        )

        return json(res, 502, {
          error: 'upstream_error',
          status: upstream.status,
          details,
        })
      }

      const content = data?.choices?.[0]?.message?.content

      if (typeof content !== 'string') {
        console.error(
          '[chat] provider response missing choices[0].message.content'
        )

        return json(res, 502, {
          error: 'bad_upstream_response',
          status: upstream.status,
          details: 'The provider response did not contain text content.',
        })
      }

      return json(res, 200, {
        content,
        model:
          typeof data.model === 'string' ? data.model : MODEL,
      })
    } catch (error) {
      const timedOut = error?.name === 'TimeoutError'

      console.error(
        `[chat] request failed: ${error?.name || 'Error'}: ${
          error?.message || 'Unknown error'
        }`
      )

      return json(res, timedOut ? 504 : 502, {
        error: timedOut ? 'provider_timeout' : 'provider_connection_failed',
        message: timedOut
          ? 'The provider took too long to respond.'
          : 'Could not get a valid response from the provider.',
      })
    }
  })
})

server.listen(PORT, () => {
  console.log(
    `Dudu chat API → http://localhost:${PORT} | provider: ${
      API_KEY ? 'TERKONFIGURASI' : 'BELUM DIKONFIGURASI'
    }`
  )
})
