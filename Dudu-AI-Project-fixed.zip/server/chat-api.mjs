// Logika API chat yang tidak bergantung pada transport.
// Dipakai oleh server HTTP development (chat-server.mjs) dan oleh proses utama Electron.

export const MAX_BODY_BYTES = 256_000
const ROLES = ['system', 'user', 'assistant']

const reply = (status, body) => ({ status, body })

/**
 * @param {ReturnType<import('./config.mjs').resolveConfig>} config
 * @param {typeof fetch} [fetchImpl]
 */
export function createChatApi(config, fetchImpl = globalThis.fetch) {
  const log = (...a) => console.error(...a)

  /**
   * @param {{ method: string, path: string, contentType?: string|null, body?: string, signal?: AbortSignal }} req
   * @returns {Promise<{status:number, body:object}>}
   */
  async function handle(req) {
    const path = String(req.path || '').split('?')[0]
    const method = String(req.method || 'GET').toUpperCase()

    if (method === 'GET' && path === '/api/health') {
      return reply(200, { configured: Boolean(config.apiKey), model: config.model })
    }
    if (method !== 'POST' || path !== '/api/chat') return reply(404, { error: 'not_found' })

    // Wajib application/json: memaksa preflight CORS pada halaman web lain sehingga
    // situs pihak ketiga tidak dapat memakai kunci API pengguna lewat request "sederhana".
    if (!/^application\/json\b/i.test(req.contentType || '')) {
      return reply(415, { error: 'unsupported_media_type' })
    }
    const raw = req.body ?? ''
    if (Buffer.byteLength(raw) > MAX_BODY_BYTES) return reply(413, { error: 'request_too_large' })

    if (!config.apiKey) {
      return reply(501, { error: 'provider_not_configured', message: 'Set DUDU_PROVIDER_API_KEY.' })
    }

    let messages
    try {
      ({ messages } = JSON.parse(raw))
    } catch {
      return reply(400, { error: 'bad_json' })
    }
    if (
      !Array.isArray(messages) || messages.length === 0 ||
      !messages.every((m) => m && typeof m.role === 'string' && ROLES.includes(m.role))
    ) {
      return reply(400, { error: 'bad_request' })
    }

    const payload = JSON.stringify({
      model: config.model,
      messages: messages.map((m) => ({ role: m.role, content: String(m.content ?? '').slice(0, 32_000) })),
    })

    const timeoutSignal = AbortSignal.timeout(config.timeoutMs)
    const signal = req.signal ? AbortSignal.any([req.signal, timeoutSignal]) : timeoutSignal

    try {
      const upstream = await fetchImpl(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.apiKey}` },
        body: payload,
        signal,
      })
      const text = await upstream.text()
      let data
      try {
        data = JSON.parse(text)
      } catch {
        log(`[chat] invalid JSON from provider; status=${upstream.status}`)
        return reply(502, { error: 'bad_upstream_response', status: upstream.status, details: 'Provider returned a non-JSON response.' })
      }
      if (!upstream.ok) {
        const details = data?.error?.message || data?.message || 'Provider request failed.'
        log(`[chat] upstream error status=${upstream.status}: ${details}`)
        return reply(502, { error: 'upstream_error', status: upstream.status, details })
      }
      const content = data?.choices?.[0]?.message?.content
      if (typeof content !== 'string') {
        log('[chat] provider response missing choices[0].message.content')
        return reply(502, { error: 'bad_upstream_response', status: upstream.status, details: 'The provider response did not contain text content.' })
      }
      return reply(200, { content, model: typeof data.model === 'string' ? data.model : config.model })
    } catch (error) {
      if (req.signal?.aborted) return reply(499, { error: 'client_closed_request' })
      const timedOut = error?.name === 'TimeoutError'
      log(`[chat] request failed: ${error?.name || 'Error'}: ${error?.message || 'Unknown error'}`)
      return reply(timedOut ? 504 : 502, {
        error: timedOut ? 'provider_timeout' : 'provider_connection_failed',
        message: timedOut ? 'The provider took too long to respond.' : 'Could not get a valid response from the provider.',
      })
    }
  }

  return { handle }
}
