// Konfigurasi provider: dibaca dari environment dan (opsional) file bergaya .env.
// Tidak ada kredensial yang ditanam di kode. Nilai environment menang atas isi file.

export const DEFAULT_BASE_URL = 'https://open.bigmodel.cn/api/paas/v4'
export const DEFAULT_MODEL = 'glm-4-flash'

/** Parser .env minimal: KEY=VALUE, komentar #, kutip tunggal/ganda, tanpa ekspansi variabel. */
export function parseEnvFile(text) {
  const out = {}
  for (const rawLine of String(text).split(/\r?\n/)) {
    const line = rawLine.trim()
    if (!line || line.startsWith('#')) continue
    const eq = line.indexOf('=')
    if (eq < 1) continue
    const key = line.slice(0, eq).trim().replace(/^export\s+/, '')
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue
    let value = line.slice(eq + 1).trim()
    const quoted = value.length >= 2 && (value[0] === '"' || value[0] === "'") && value.at(-1) === value[0]
    if (quoted) value = value.slice(1, -1)
    else value = value.replace(/\s+#.*$/, '')
    out[key] = value
  }
  return out
}

/** Gabungkan file (prioritas rendah) dengan env (prioritas tinggi) menjadi konfigurasi final. */
export function resolveConfig(env = {}, fileValues = {}) {
  const get = (k) => {
    const fromEnv = env[k]
    if (typeof fromEnv === 'string' && fromEnv.trim() !== '') return fromEnv.trim()
    const fromFile = fileValues[k]
    return typeof fromFile === 'string' && fromFile.trim() !== '' ? fromFile.trim() : undefined
  }
  const timeout = Number(get('DUDU_TIMEOUT_MS'))
  return {
    apiKey: get('DUDU_PROVIDER_API_KEY'),
    baseUrl: (get('DUDU_PROVIDER_BASE_URL') || DEFAULT_BASE_URL).replace(/\/+$/, ''),
    model: get('DUDU_MODEL') || DEFAULT_MODEL,
    port: Number(get('PORT')) || 8787,
    timeoutMs: Number.isFinite(timeout) && timeout >= 1000 ? timeout : 30_000,
  }
}

export const ENV_TEMPLATE = `# Konfigurasi provider Dudu AI.
# Isi DUDU_PROVIDER_API_KEY dengan kunci milik Anda sendiri. Jangan bagikan file ini.
# Nilai yang diatur lewat environment variable sistem menimpa nilai di file ini.
# Perubahan berlaku pada permintaan chat berikutnya (tidak perlu memasang ulang aplikasi).

DUDU_PROVIDER_API_KEY=
DUDU_PROVIDER_BASE_URL=${DEFAULT_BASE_URL}
DUDU_MODEL=${DEFAULT_MODEL}
`
