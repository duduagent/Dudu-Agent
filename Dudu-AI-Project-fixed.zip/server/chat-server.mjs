// Server HTTP untuk DEVELOPMENT / mode web. Aplikasi desktop TIDAK memakai file ini:
// di sana API dijalankan di dalam proses utama Electron tanpa membuka port TCP.
import http from 'node:http'
import fs from 'node:fs'
import { createChatApi, MAX_BODY_BYTES } from './chat-api.mjs'
import { parseEnvFile, resolveConfig } from './config.mjs'

const HOST = '127.0.0.1' // hanya loopback; jangan buka endpoint berkunci API ke jaringan

let fileValues = {}
try { fileValues = parseEnvFile(fs.readFileSync('.env', 'utf8')) } catch { /* .env opsional */ }
const config = resolveConfig(process.env, fileValues)
const api = createChatApi(config)

const send = (res, { status, body }) => {
  if (res.writableEnded || res.destroyed) return
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

const server = http.createServer((req, res) => {
  const ac = new AbortController()
  res.on('close', () => { if (!res.writableFinished) ac.abort() })

  const chunks = []
  let size = 0
  let tooLarge = false
  req.on('data', (chunk) => {
    size += chunk.length
    if (size > MAX_BODY_BYTES) { tooLarge = true; return }
    chunks.push(chunk)
  })
  req.on('end', async () => {
    if (tooLarge) return send(res, { status: 413, body: { error: 'request_too_large' } })
    const result = await api.handle({
      method: req.method,
      path: req.url,
      contentType: req.headers['content-type'],
      body: Buffer.concat(chunks).toString('utf8'),
      signal: ac.signal,
    })
    send(res, result)
  })
})

server.listen(config.port, HOST, () => {
  console.log(`Dudu chat API → http://${HOST}:${config.port} | provider: ${config.apiKey ? 'TERKONFIGURASI' : 'BELUM DIKONFIGURASI'}`)
})
