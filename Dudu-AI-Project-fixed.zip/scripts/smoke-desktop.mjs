// Smoke test aplikasi desktop yang SUDAH DIBANGUN. Menjalankan biner sungguhan dengan profil terisolasi,
// mengendalikannya lewat Chrome DevTools Protocol, lalu memverifikasi perilaku utama.
//
// Pakai:   node scripts/smoke-desktop.mjs <path-ke-biner> [--no-sandbox]
// Linux tanpa display:  xvfb-run -a node scripts/smoke-desktop.mjs release/linux-unpacked/dudu-ai
// Perlu Node >= 22 (WebSocket bawaan). Keluar dengan kode 1 jika ada pemeriksaan yang gagal.
import { spawn } from 'node:child_process'
import http from 'node:http'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const bin = process.argv[2]
const extra = process.argv.slice(3)
if (!bin || !fs.existsSync(bin)) { console.error('Berkas biner tidak ditemukan:', bin); process.exit(2) }

const home = fs.mkdtempSync(path.join(os.tmpdir(), 'dudu-smoke-'))
const PORT = 9300 + Math.floor(Math.random() * 500)
const results = []
const check = (name, ok, detail = '') => { results.push({ name, ok }); console.log(`${ok ? 'LULUS ' : 'GAGAL '} ${name}${detail ? ` — ${detail}` : ''}`) }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function launch() {
  const env = { ...process.env, HOME: home, XDG_CONFIG_HOME: path.join(home, '.config'), APPDATA: path.join(home, 'AppData'), DUDU_PROVIDER_API_KEY: '' }
  delete env.DUDU_DEV_URL
  const child = spawn(bin, [`--remote-debugging-port=${PORT}`, ...extra], { env, stdio: ['ignore', 'pipe', 'pipe'], cwd: os.tmpdir() }) // cwd BUKAN folder proyek
  let log = ''
  child.stdout.on('data', (d) => { log += d })
  child.stderr.on('data', (d) => { log += d })
  child.getLog = () => log
  return child
}

async function connect() {
  for (let i = 0; i < 80; i++) {
    try {
      const targets = await (await fetch(`http://127.0.0.1:${PORT}/json`)).json()
      const page = targets.find((t) => t.type === 'page')
      if (page) return page.webSocketDebuggerUrl
    } catch { /* belum siap */ }
    await sleep(250)
  }
  throw new Error('DevTools endpoint tidak muncul — aplikasi gagal start?')
}

class Cdp {
  constructor(url) {
    this.id = 0; this.pending = new Map(); this.events = []
    this.ws = new WebSocket(url)
    this.ready = new Promise((res, rej) => { this.ws.onopen = res; this.ws.onerror = rej })
    this.ws.onmessage = (m) => {
      const msg = JSON.parse(m.data)
      if (msg.id && this.pending.has(msg.id)) { this.pending.get(msg.id)(msg); this.pending.delete(msg.id) } else this.events.push(msg)
    }
  }
  send(method, params = {}) {
    const id = ++this.id
    return new Promise((res) => { this.pending.set(id, res); this.ws.send(JSON.stringify({ id, method, params })) })
  }
  async eval(expression) {
    const r = await this.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true })
    if (r.result?.exceptionDetails) throw new Error(r.result.exceptionDetails.exception?.description || 'eval error')
    return r.result?.result?.value
  }
  async waitFor(expression, timeout = 10000) {
    const t0 = Date.now()
    while (Date.now() - t0 < timeout) { try { if (await this.eval(expression)) return true } catch { /* ulang */ } await sleep(200) }
    return false
  }
}

async function session(label, fn) {
  console.log(`\n=== ${label} ===`)
  const child = launch()
  let exited = null
  child.on('exit', (code, sig) => { exited = { code, sig } })
  try {
    const cdp = new Cdp(await connect())
    await cdp.ready
    await cdp.send('Runtime.enable'); await cdp.send('Log.enable'); await cdp.send('Network.enable')
    await fn(cdp, child)
    return cdp
  } catch (e) {
    check(`${label}: sesi berjalan tanpa error`, false, e.message)
    console.log(child.getLog().split('\n').slice(-15).join('\n'))
  } finally {
    child.kill('SIGTERM')
    for (let i = 0; i < 40 && !exited; i++) await sleep(100)
    if (!exited) child.kill('SIGKILL')
  }
}

const typeAndSend = async (cdp, text) => {
  await cdp.eval(`document.getElementById('composer').focus()`)
  await cdp.send('Input.insertText', { text })
  for (const type of ['rawKeyDown', 'keyUp']) {
    await cdp.send('Input.dispatchKeyEvent', { type, key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, text: type === 'rawKeyDown' ? '\r' : undefined })
  }
}

let consoleProblems = []
// Satu-satunya log yang DIHARAPKAN: smoke test ini sengaja berjalan tanpa API key, sehingga /api/chat
// membalas 501 (kontrak "provider belum dikonfigurasi") dan Chromium mencatat setiap respons non-2xx.
const EXPECTED_LOGS = [/status of 501 \(Not Implemented\).*dudu:\/\/app\/api\/chat/]
const isExpected = (text) => EXPECTED_LOGS.some((re) => re.test(text))
const collectProblems = (cdp) => {
  for (const ev of cdp.events) {
    if (ev.method === 'Runtime.exceptionThrown') consoleProblems.push('exception: ' + (ev.params.exceptionDetails.exception?.description || ev.params.exceptionDetails.text))
    if (ev.method === 'Runtime.consoleAPICalled' && ['error', 'assert'].includes(ev.params.type)) consoleProblems.push('console.' + ev.params.type + ': ' + ev.params.args.map((a) => a.value ?? a.description).join(' '))
    if (ev.method === 'Log.entryAdded' && ev.params.entry.level === 'error') {
      const text = ev.params.entry.text + ' ' + (ev.params.entry.url || '')
      if (!isExpected(text)) consoleProblems.push('log: ' + text)
    }
  }
}

// ---- Sesi 1: peluncuran pertama ----
const externalRequests = []
await session('Peluncuran pertama', async (cdp) => {
  check('Halaman dimuat dari dudu://app (bukan http dev server)', await cdp.waitFor(`location.href.startsWith('dudu://app')`), await cdp.eval('location.href'))
  check('Judul jendela "Dudu — AI Workforce & Agent OS" dimuat', (await cdp.eval('document.title')).includes('Dudu'))
  check('UI render: heading "Halo! Saya Dudu."', await cdp.waitFor(`document.querySelector('h1')?.textContent.includes('Halo! Saya Dudu')`))
  check('Preload: window.dudu.isDesktop === true', (await cdp.eval('window.dudu && window.dudu.isDesktop')) === true)
  check('Isolasi: tidak ada require/process/Buffer di halaman', (await cdp.eval(`[typeof require, typeof process, typeof Buffer].join(',')`)) === 'undefined,undefined,undefined')
  check('Kunci API tidak ada di bundle frontend', !(await cdp.eval(`fetch('/assets/'+[...document.scripts].map(s=>s.src.split('/').pop()).find(Boolean)).then(r=>r.text()).then(t=>/DUDU_PROVIDER_API_KEY\\s*[:=]\\s*["'][A-Za-z0-9]/.test(t)||/sk-[A-Za-z0-9]{16,}/.test(t))`)))

  await typeAndSend(cdp, 'Halo Dudu desktop')
  check('Enter mengirim: pesan pengguna tampil di .msg-row.user', await cdp.waitFor(`document.querySelectorAll('.msg-row.user').length===1 && document.querySelector('.msg-row.user .msg-text').textContent.includes('Halo Dudu desktop')`))
  check('Textarea dikosongkan setelah kirim', (await cdp.eval(`document.getElementById('composer').value`)) === '')
  check('Provider tanpa kunci → error jujur + tombol Coba lagi (tanpa respons palsu)', await cdp.waitFor(`document.querySelector('.msg-error')?.textContent.includes('DUDU_PROVIDER_API_KEY') && /Coba lagi/.test(document.querySelector('.msg-error').textContent)`))
  check('Tepat satu pesan pengguna (tidak terkirim ganda)', (await cdp.eval(`document.querySelectorAll('.msg-row.user').length`)) === 1)
  await cdp.eval(`document.getElementById('composer').focus()`)
  await cdp.send('Input.insertText', { text: 'baris1' })
  await cdp.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, modifiers: 8 })
  await cdp.send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, modifiers: 8 })
  check('Shift+Enter tidak mengirim', (await cdp.eval(`document.querySelectorAll('.msg-row.user').length`)) === 1)
  await cdp.eval(`(()=>{const t=document.getElementById('composer');const s=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;s.call(t,'');t.dispatchEvent(new Event('input',{bubbles:true}))})()`)

  const bodyFont = await cdp.eval(`document.fonts.ready.then(()=>[...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family).join(',')) `)
  check('Font Inter dimuat dari bundel lokal', /Inter/.test(bodyFont), bodyFont)
  const w = await cdp.eval(`[document.documentElement.scrollWidth, window.innerWidth].join('/')`)
  const [sw, iw] = w.split('/').map(Number)
  check('Layout tidak overflow horizontal pada ukuran jendela default', sw <= iw, w)
  collectProblems(cdp)
  for (const ev of cdp.events) if (ev.method === 'Network.requestWillBeSent' && /^https?:/.test(ev.params.request.url)) externalRequests.push(ev.params.request.url)
  // Probe NEGATIF (sengaja memicu 415/403/pelanggaran CSP) dijalankan SETELAH pengumpulan error,
  // supaya log yang ia timbulkan tidak tercampur dengan error aplikasi yang sebenarnya.
  const health = await cdp.eval(`fetch('/api/health').then(r=>r.json())`)
  check('GET /api/health lewat protokol internal (tanpa port TCP)', health && health.configured === false, JSON.stringify(health))
  const noCt = await cdp.eval(`fetch('/api/chat',{method:'POST',headers:{'Content-Type':'text/plain'},body:'{}'}).then(r=>r.status)`)
  check('POST /api/chat tanpa Content-Type JSON ditolak (415)', noCt === 415, String(noCt))
  const traversal = await cdp.eval(`fetch('/..%2f..%2fpackage.json').then(r=>r.status).catch(()=>'err')`)
  check('Path traversal ke luar dist/ tidak menghasilkan berkas', traversal !== 200, String(traversal))
  const ext = await cdp.eval(`fetch('https://example.com/',{mode:'no-cors'}).then(()=>'terkirim').catch(()=>'diblokir')`)
  check('CSP memblokir request keluar ke domain eksternal', ext === 'diblokir', ext)
  const hasCsp = await cdp.eval(`fetch('/').then(r=>r.headers.get('content-security-policy')||'')`)
  check('Header Content-Security-Policy terpasang', hasCsp.includes("default-src 'self'"))

})
check('Tidak ada request http(s) eksternal saat startup/penggunaan normal', externalRequests.filter((u) => !u.startsWith('https://example.com')).length === 0, externalRequests.filter((u) => !u.startsWith('https://example.com')).join(', '))
check('Tidak ada console error / exception di renderer', consoleProblems.length === 0, consoleProblems.slice(0, 3).join(' | '))

// ---- Sesi 2: buka ulang dengan profil yang sama ----
await session('Buka ulang (profil sama)', async (cdp) => {
  check('Percakapan dipulihkan setelah aplikasi dibuka ulang', await cdp.waitFor(`document.querySelectorAll('.msg-row.user').length===1 && document.querySelector('.msg-row.user .msg-text').textContent.includes('Halo Dudu desktop')`))
  check('Sidebar menampilkan judul percakapan tersimpan', await cdp.eval(`[...document.querySelectorAll('.conv-title')].some(b=>b.textContent.includes('Halo Dudu desktop'))`))
})

// ---- Sesi 3: provider terkonfigurasi lewat dudu.env (provider PALSU lokal; bukan uji provider asli) ----
const seenAuth = []
const mock = http.createServer((req, res) => {
  let body = ''
  req.on('data', (c) => { body += c })
  req.on('end', () => {
    seenAuth.push(req.headers.authorization)
    const n = JSON.parse(body).messages.length
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ model: 'mock-model', choices: [{ message: { content: `Balasan dari mock (riwayat=${n})` } }] }))
  })
})
await new Promise((r) => mock.listen(0, '127.0.0.1', r))
const userData = process.platform === 'win32' ? path.join(home, 'AppData', 'Dudu AI') : path.join(home, '.config', 'Dudu AI')
fs.mkdirSync(userData, { recursive: true })
fs.writeFileSync(path.join(userData, 'dudu.env'), `DUDU_PROVIDER_API_KEY=kunci-uji-smoke\nDUDU_PROVIDER_BASE_URL=http://127.0.0.1:${mock.address().port}\nDUDU_MODEL=mock-model\n`, { mode: 0o600 })
await session('Provider terkonfigurasi via dudu.env', async (cdp) => {
  check('Health melaporkan configured=true dari dudu.env', await cdp.waitFor(`fetch('/api/health').then(r=>r.json()).then(j=>j.configured===true)`))
  await cdp.waitFor(`document.getElementById('composer')`)
  await typeAndSend(cdp, 'Pesan kedua')
  check('Balasan assistant tampil (jalur sukses end-to-end)', await cdp.waitFor(`document.body.textContent.includes('Balasan dari mock')`))
  check('Pill status menampilkan Terhubung · mock-model', await cdp.waitFor(`document.querySelector('.pill.ok')?.textContent.includes('mock-model')`))
  check('Provider menerima header Authorization dari dudu.env', seenAuth.includes('Bearer kunci-uji-smoke'), String(seenAuth.length) + ' request')
  check('Kunci API tidak bocor ke DOM/localStorage renderer', !(await cdp.eval(`document.documentElement.outerHTML.includes('kunci-uji-smoke') || JSON.stringify(localStorage).includes('kunci-uji-smoke')`)))
  check('Riwayat ke provider tepat 3 pesan: system + pesan lama + pesan baru (pesan error terfilter)', await cdp.waitFor(`document.body.textContent.includes('riwayat=3)')`))
})
mock.close()

// ---- Lokasi data ----
const files = []
const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); e.isDirectory() ? walk(p) : files.push(p) } }
walk(home)
const dataDirs = [...new Set(files.filter((f) => /Local Storage/.test(f)).map((f) => path.dirname(f)))]
check('Data pengguna disimpan di folder data aplikasi OS (bukan folder kerja/instalasi)', dataDirs.length > 0 && dataDirs.every((d) => d.startsWith(home)), dataDirs.map((d) => path.relative(home, d)).join(', '))

fs.rmSync(home, { recursive: true, force: true })
const failed = results.filter((r) => !r.ok)
console.log(`\nRINGKASAN: ${results.length - failed.length}/${results.length} pemeriksaan lulus`)
process.exit(failed.length ? 1 : 0)
