# Laporan Audit, Implementasi & Verifikasi — Dudu AI 0.2.0

Status: **PASS** = diverifikasi · **PARTIAL** = sebagian berfungsi · **BLOCKED** = terhalang dependensi/layanan eksternal tertentu · **NOT RUN** = belum diuji.
Lingkungan: Ubuntu 24.04 container x86_64, Node 22.22, Electron 44.7, electron-builder 26, wine 9.0 (hanya build Windows), LibreOffice/python-docx/openpyxl/python-pptx/reportlab (hanya untuk membuat fixture).

## 1. Temuan audit awal (sebelum mengubah apa pun)
- **Premis prompt tidak cocok dengan workspace.** Laporan "Workbuddy" (14 file tes, 181 tes, API upload, ekstraksi, 17 smoke HTTP) **tidak** menggambarkan kode ini. Workspace awal: 7 file tes / 56 tes (direproduksi lulus), dan **tidak ada** kode upload, lampiran, ekstraksi, RAG, vision, maupun misi. Laporan lama diperlakukan sebagai tidak terbukti.
- Status nyata sidebar: Chat berfungsi. **"Misi & Tugas" ternyata menampilkan modul Reminder** (bukan misi). Enam menu lain placeholder jujur. Halaman non-chat **tidak punya tombol buka sidebar** (jalan buntu di layar sempit). Panel kanan berisi tiga klaim statis ("misi direncanakan", "Milestone F", "belum ada tool") yang menjadi keliru begitu fitur ada. Tombol mic sudah nonaktif dengan keterangan jujur; tidak ada tombol lampiran.
- Pada baseline tidak ada kegagalan tes yang tersisa.

## 2. Keputusan arsitektur
- Backend dipisah menjadi modul tanpa transport (`server/api.mjs` + `files`, `extract`, `knowledge`, `missions`, `data-tools`, `chat-api`), dipakai bersama oleh server HTTP dev (`127.0.0.1`) dan proses utama Electron (skema `dudu://app`, **tanpa port TCP**). Kontrak `/api/chat` lama tidak berubah; field baru (`fileIds`, `useKnowledge`, `attachments`, `sources`) bersifat opsional dan hanya muncul bila dipakai.
- Penyimpanan: `<userData>/data/{files,kb,missions,artifacts}`; ID acak (UUID); nama dari pengguna **tidak pernah** menjadi path disk; tulis atomik.
- Dependensi baru: hanya `fflate` (ZIP/Office) dan `unpdf` (PDF). Tidak ada vector DB, OCR, atau ffmpeg yang dibundel.
- Retrieval: **BM25 leksikal** (bukan embedding). Perencana misi: **berbasis aturan** (bukan LLM).
- Vision/STT aktif **hanya** bila `DUDU_VISION_MODEL` / `DUDU_STT_MODEL` diatur eksplisit; tidak ada tebakan model dan tidak ada penggantian provider diam-diam.

## 3. Status per fase
| Area | Status | Bukti / catatan |
|---|---|---|
| Sidebar: 9 menu, navigasi, status aktif | **PASS** | `pages.test.tsx` (jsdom↔server nyata) + smoke pada app terpaket |
| Sidebar: collapsible desktop, overlay mobile, keyboard | **PASS** | `layout.test.tsx` (+3 regresi), smoke 800 px & 390 px × 8 halaman tanpa overflow, tombol menu di semua halaman |
| Halaman: Files, Knowledge Base, Misi, Workforce, Tools, Memory, Pengaturan | **PASS** | data nyata; state loading/empty/error/retry diuji |
| Memory | **PARTIAL** | hanya catatan **eksplisit** buatan pengguna (CRUD, masuk system prompt bila aktif). Memori otomatis: **tidak ada** |
| Workforce | **PARTIAL** | hanya mendaftar 1 pelaksana lokal nyata; agen LLM otonom/adapter eksternal dinyatakan "Belum diimplementasikan" |
| Composer: menu lampiran, multi-file, pratinjau, hapus, drag-drop, paste, dari Files, Enter/Shift+Enter | **PASS** | `attachments-ui.test.tsx` (16), smoke dengan `<input type=file>` asli |
| Composer: progress unggahan | **PARTIAL** | persen nyata hanya bila transport mengirim event; di desktop (`dudu://`) **tidak ada event progress** (terukur) → UI memakai indikator tak-tentu, tanpa persen palsu |
| Composer: pembatalan unggahan | **PASS (jsdom)** / **NOT RUN (desktop)** | abort XHR + tidak menyimpan file diuji di jsdom; belum diuji pada app terpaket |
| Composer: kamera, rekam mikrofon | **BLOCKED / tidak diimplementasikan** | tidak ditampilkan sebagai tersedia; mic tetap nonaktif dengan alasan |
| Dokumen: TXT/MD/CSV/JSON/XML/YAML/log/kode, DOCX, XLSX, PPTX, ODT/ODS/ODP, RTF, HTML, PDF teks, ZIP (daftar) | **PASS** | diuji terhadap berkas dari software independen (`real-fixtures.test.mjs`) dan dalam `app.asar` |
| PDF pindaian / OCR | **BLOCKED** | OCR tidak diimplementasikan; dilaporkan jujur "tidak dapat dibaca", tidak pernah dilabeli sukses |
| Gambar → vision | **PARTIAL** | pipeline (base64 `image_url`, model & kunci terpisah) diverifikasi lewat perekam payload; **panggilan ke model vision sungguhan: NOT RUN** (tanpa kunci) |
| Audio → transkripsi | **PARTIAL** | pemanggilan `/audio/transcriptions`, cache transkrip, dan kegagalan diuji dengan provider palsu; **layanan nyata: NOT RUN** |
| Video | **tidak diimplementasikan** | hanya disimpan; dinyatakan di UI |
| Data terstruktur (CSV/TSV/JSON/JSONL/XLSX) | **PASS** | parser + profil, nilai diketahui |
| Pelaporan tahap file (dipilih → diunggah → tersimpan → terbaca → siap → dianalisis/gagal) | **PASS** | chip & pesan; "dianalisis" hanya bila isi benar-benar dikirim dan balasan sukses |
| Knowledge Base: ingest, chunking+overlap, indeks persisten, retrieval, sitasi (hal./slide/sheet), sinkronisasi hapus, indeks rusak | **PASS** (leksikal) | `knowledge.test.mjs`, `chat-attachments.test.mjs`, smoke |
| Embedding / pencarian semantik | **tidak diimplementasikan** | UI menyatakan "bukan embedding semantik" |
| RAG end-to-end dengan LLM nyata | **NOT RUN** | payload ke model terbukti memuat konteks `[S#]`; jawaban model nyata tidak diuji |
| Misi end-to-end (1 template: analisis data) | **PASS** | lihat §6 |
| Keamanan (§7) | **PASS** untuk butir yang diuji | lihat §5 |
| Build Linux (AppImage + deb) dan smoke app terpaket | **PASS** | §4 |
| Build Windows | **PASS (build)** · **NOT RUN (dijalankan)** | belum ditandatangani; belum pernah dijalankan di Windows |
| GitHub Actions | **NOT RUN** | hanya sintaks YAML |

## 4. Perintah dan hasil
| Perintah | Hasil |
|---|---|
| `npm ci` (dari ekstraksi ZIP bersih) | PASS |
| `npm run typecheck` | PASS (0 error) |
| `npm test` | **PASS — 15 file tes ditemukan di disk, 15 dieksekusi; 167 tes, 167 lulus, 0 dilewati** |
| `npm run build` | PASS |
| `npm run dist:linux` | PASS → AppImage ≈123 MB, .deb ≈98 MB |
| `npm run dist:win` (Linux + wine) | PASS (build) → Setup ≈102 MB, Portable ≈102 MB; **tidak ditandatangani** (cert 0 byte, diperiksa `pefile`) |
| `node scripts/smoke-desktop.mjs` — AppImage final | **PASS 51/51** |
| idem — `.deb` terpasang di `/opt` (hash `app.asar` terpasang = hasil build) | **PASS 51/51** |
| Lint | tidak tersedia (tidak ada konfigurasi ESLint) |

Rincian tes: api 9 · app-resilience 3 · attachments-ui 16 · chat-api 15 · chat-attachments 17 · composer 8 · desktop-helpers 14 · files-extract 20 · knowledge 9 · layout 6 · missions 13 · pages 16 · real-fixtures 8 · reminders 4 · storage 9. Hanya keluaran non-kosong: peringatan pdf.js "Indexing all PDF objects" pada tes PDF korup yang disengaja.

## 5. Bug nyata yang ditemukan dan diperbaiki (dengan regresi)
| Bug | Cara ditemukan |
|---|---|
| **RTF dari LibreOffice menghasilkan sampah biner berstatus "extracted"** → akan disuntikkan ke model | berkas asli; ditulis ulang sebagai tokenizer RTF + pengaman "teks penuh karakter kontrol = rusak" |
| ODP tanpa penanda slide (halaman catatan ikut terhitung); tabel ODT berlabel "Sheet" | berkas asli LibreOffice |
| Transkrip audio yang sah dibuang karena memeriksa status ekstraksi lama | tes chat dengan STT |
| Anggaran konteks lampiran dihabiskan oleh pesan **lama**; lampiran terbaru bisa tak terbaca | review; kini dialokasikan terbaru→lama |
| Respons `/api/capabilities` bentuk salah → UI crash (layar putih) | tes lama gagal setelah perubahan; kini divalidasi |
| `chunkText`: sisa overlap menjadi chunk duplikat pada pergantian halaman | sanity check |
| `URL.origin` Node = `"null"` untuk skema `dudu://` → app menolak dirinya sendiri | tes helper |
| CSP unduhan (`sandbox`) tertimpa CSP aplikasi | smoke pada app terpaket |
| Panel kanan: teks stale ("direncanakan", "Milestone F", "belum ada tool") | tes; kini data nyata |
| Halaman non-chat tanpa tombol sidebar; overlay sidebar menutupi konten saat layar menyempit | audit + screenshot; diperbaiki + 3 tes |
| **Overflow horizontal saat panel kanan ditutup di desktop** (`.sr-only` absolut lolos dari `overflow:hidden`; CSS asli) | smoke responsif pada app terpaket |
| Progress unggahan "0%" menyesatkan di desktop | smoke: event progress = 0 pada `dudu://` |

Uji mutasi: verifikasi misi sengaja dirusak → tes tamper gagal (membuktikan tes bermakna).

## 6. Bukti eksekusi misi (template "analisis data")
Alur: tujuan → misi **Draft** dengan 5 kriteria penerimaan eksplisit + 5 langkah → **persetujuan manusia** → Queued → Running → eksekusi tool lokal (`input.validate`, `data.load`, `data.profile`, `report.write`, `verify.criteria`) → artefak `report.md`+`profile.json` (ukuran, SHA-256) → verifikasi **independen** (baca ulang dari disk; hitung-ulang baris dengan implementasi terpisah; hitung-ulang min/maks/total dari data mentah) → Completed. Tiap langkah: ID eksekusi, stempel waktu, percobaan. Kegagalan diklasifikasi (`input_invalid`/`parse_error` → Failed; `tool_error` → retry otomatis maks. 1× lalu Needs Attention retryable; `verification_failed` → Needs Attention, tidak retryable). Misi terputus saat app ditutup dipulihkan sebagai Needs Attention. Diuji: `missions.test.mjs` (13), UI (`pages.test.tsx`), dan pada app terpaket (kriteria "lulus" 5/5, bukti "hitung-ulang=4, laporan=4, profile.json=4", artefak terunduh dengan header attachment+sandbox).
**Batas jujur:** perencana berbasis aturan; satu template; bukan agen LLM; tidak ada coding-agent/integrasi eksternal.

## 7. Keamanan (diperiksa)
Model Electron tidak dilemahkan (sandbox, contextIsolation, tanpa Node/IPC, CSP ketat, izin hanya notifikasi). Baru diverifikasi: nama file tidak menjadi path (traversal), ID divalidasi, executable & ekstensi palsu ditolak (magic bytes), batas ukuran (server + klien), zip bomb & path berbahaya di ZIP (tanpa ekstraksi ke disk), HTML/SVG tidak pernah dirender inline, unduhan `attachment` + `nosniff` + CSP `sandbox`, anti-CSRF header kustom pada semua request yang mengubah data, `/api/chat` wajib JSON, server dev hanya loopback, log tidak memuat isi file/kunci, indeks/misi/metadata rusak tidak membuat crash, object URL di-revoke. **Tidak diaudit:** pembersihan file `*.tmp` sisa bila proses mati tepat saat menulis; isolasi data antar-percakapan di sisi server (file bersifat global per perangkat, tidak per percakapan).

## 8. Koreksi atas klaim saya sebelumnya
Pada laporan rilis 0.1.0 saya menyebut smoke test AppImage "29/29". Setelah ditemukan bahwa `SIGTERM` pada pembungkus AppImage **tidak mematikan proses Electron** (terbukti: DevTools masih menjawab), sesi "buka ulang" pada pengujian AppImage itu kemungkinan tersambung ke instance lama — bukti pembukaan ulang untuk AppImage **tidak sahih**; untuk `.deb`/folder unpacked (biner dijalankan langsung) tetap sahih. Skrip kini menjalankan tiap sesi dalam grup proses sendiri, mematikan seluruh grup, dan **menggagalkan** sesi bila instance sebelumnya masih menjawab. AppImage 0.2.0 diuji ulang dengan skrip ini: 51/51.

## 9. Belum diuji / keterbatasan
- **Provider AI sungguhan** (chat, vision, STT, RAG dengan jawaban model): NOT RUN — tanpa kredensial. Hanya provider palsu yang merekam payload.
- **Windows asli**: installer/portable/uninstall/SmartScreen/notifikasi — NOT RUN. Uji installer di wine tidak konklusif (lihat PACKAGING.md).
- Pembatalan unggahan pada app terpaket; distro Linux selain Ubuntu 24.04; arm64; layar fisik/sentuh (diuji lewat CDP + Xvfb).
- Tidak ada: OCR, video, kamera, mikrofon, embedding, agen LLM, integrasi pihak ketiga.

## 10. Langkah berikutnya yang disarankan
1) Uji vision/STT/chat dengan kunci nyata (set `DUDU_VISION_MODEL`, `DUDU_STT_MODEL`). 2) Jalankan CI di runner Windows asli dan uji installer. 3) OCR (mis. tesseract.js) untuk PDF pindaian. 4) Embedding + hybrid retrieval bila provider mendukung. 5) Planner berbantuan LLM dengan kebijakan persetujuan yang sama. 6) Scoping file per percakapan bila diperlukan.
