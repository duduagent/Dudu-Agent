// Router API terpadu (tanpa transport). Dipakai oleh server HTTP dev dan proses utama Electron.
import { createChatApi } from './chat-api.mjs'
import { capabilitiesOf } from './config.mjs'
import { FileError, createFileStore, isFileId, readiness } from './files.mjs'
import { createKnowledgeBase } from './knowledge.mjs'
import { MissionError, createMissionService, isMissionId } from './missions.mjs'

const json = (status, body) => ({ status, body })
const INLINE_IMAGE = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif'])

function download({ bytes, name, mime, inline }) {
  const safeInline = inline && INLINE_IMAGE.has(mime)
  const encoded = encodeURIComponent(name).replace(/['()]/g, escape)
  return {
    status: 200,
    raw: bytes,
    headers: {
      'Content-Type': safeInline ? mime : 'application/octet-stream',
      'Content-Disposition': `${safeInline ? 'inline' : 'attachment'}; filename*=UTF-8''${encoded}`,
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "sandbox; default-src 'none'", // konten unggahan tidak boleh menjalankan skrip
      'Cache-Control': 'no-store',
    },
  }
}

/**
 * @param {{ getConfig: () => ReturnType<import('./config.mjs').resolveConfig>, dataDir: string, fetchImpl?: typeof fetch }} opts
 */
export function createApi({ getConfig, dataDir, fetchImpl = globalThis.fetch }) {
  const files = createFileStore({ dataDir, maxUploadBytes: getConfig().maxUploadBytes })
  const kb = createKnowledgeBase({ dataDir, files })
  const missions = createMissionService({ dataDir, files })

  const withReadiness = (m, caps) => ({ ...m, readiness: readiness(m, caps) })

  async function route(req) {
    const config = getConfig()
    const caps = capabilitiesOf(config)
    const method = String(req.method || 'GET').toUpperCase()
    const path = String(req.path || '').split('?')[0]
    const query = new URLSearchParams(String(req.path || '').split('?')[1] ?? '')

    if (path === '/api/chat' || path === '/api/health') return createChatApi(config, fetchImpl, { files, kb }).handle(req)

    // Anti-CSRF untuk semua request yang mengubah data: header kustom memaksa preflight CORS pada situs lain.
    if (method !== 'GET' && !req.headers?.['x-dudu-client']) return json(403, { error: 'forbidden', message: 'Header X-Dudu-Client wajib untuk request yang mengubah data.' })

    const readJson = () => { try { return JSON.parse(req.body || '{}') } catch { throw new FileError(400, 'bad_json', 'JSON tidak valid.') } }
    let m

    if (method === 'GET' && path === '/api/capabilities') return json(200, caps)

    /* ---------- file ---------- */
    if (path === '/api/files') {
      if (method === 'GET') return json(200, { files: (await files.list()).map((f) => withReadiness(f, caps)) })
      if (method === 'POST') {
        let name
        try { name = decodeURIComponent(req.headers?.['x-file-name'] ?? '') } catch { throw new FileError(400, 'bad_name', 'Nama file tidak valid.') }
        if (!name) throw new FileError(400, 'missing_name', 'Header X-File-Name wajib.')
        if (!req.bytes) throw new FileError(400, 'empty_file', 'Badan permintaan kosong.')
        return json(201, { file: withReadiness(await files.save({ name, bytes: req.bytes }), caps) })
      }
    }
    if ((m = /^\/api\/files\/([^/]+)$/.exec(path))) {
      const id = m[1]
      if (!isFileId(id)) throw new FileError(400, 'bad_id', 'ID file tidak valid.')
      if (method === 'GET') { const f = await files.get(id); return f ? json(200, { file: withReadiness(f, caps) }) : json(404, { error: 'not_found' }) }
      if (method === 'DELETE') {
        const ok = await files.remove(id)
        if (ok) await kb.removeFile(id) // sinkronisasi indeks
        return ok ? json(200, { deleted: true }) : json(404, { error: 'not_found' })
      }
    }
    if ((m = /^\/api\/files\/([^/]+)\/(content|text)$/.exec(path)) && method === 'GET') {
      const id = m[1]
      if (!isFileId(id)) throw new FileError(400, 'bad_id', 'ID file tidak valid.')
      const f = await files.get(id)
      if (!f) return json(404, { error: 'not_found' })
      if (m[2] === 'text') { const t = await files.readText(id); return json(200, { text: t == null ? null : t.slice(0, 20000), totalChars: t?.length ?? 0, truncated: (t?.length ?? 0) > 20000 }) }
      return download({ bytes: await files.readBytes(id), name: f.name, mime: f.mime, inline: query.get('inline') === '1' })
    }

    /* ---------- knowledge base ---------- */
    if (method === 'GET' && path === '/api/kb') return json(200, await kb.stats())
    if (method === 'POST' && path === '/api/kb/docs') {
      const { fileId } = readJson()
      if (!isFileId(fileId)) throw new FileError(400, 'bad_id', 'fileId tidak valid.')
      try { return json(201, await kb.indexFile(fileId)) } catch (e) { if (e.status) throw new FileError(e.status, e.code, e.message); throw e }
    }
    if ((m = /^\/api\/kb\/docs\/([^/]+)$/.exec(path)) && method === 'DELETE') {
      if (!isFileId(m[1])) throw new FileError(400, 'bad_id', 'ID tidak valid.')
      return (await kb.removeFile(m[1])) ? json(200, { deleted: true }) : json(404, { error: 'not_found' })
    }
    if (method === 'POST' && path === '/api/kb/search') {
      const { query: q, limit } = readJson()
      if (typeof q !== 'string' || !q.trim()) throw new FileError(400, 'bad_query', 'Query kosong.')
      return json(200, { results: await kb.search(q.slice(0, 500), { limit: Math.min(Math.max(Number(limit) || 5, 1), 10) }) })
    }

    /* ---------- misi ---------- */
    if (path === '/api/missions') {
      if (method === 'GET') return json(200, { missions: await missions.list() })
      if (method === 'POST') { const b = readJson(); return json(201, { mission: await missions.create({ goal: b.goal, fileId: b.fileId }) }) }
    }
    if ((m = /^\/api\/missions\/([^/]+)$/.exec(path))) {
      if (!isMissionId(m[1])) throw new MissionError(400, 'bad_id', 'ID misi tidak valid.')
      if (method === 'GET') { const x = await missions.get(m[1]); return x ? json(200, { mission: x }) : json(404, { error: 'not_found' }) }
      if (method === 'DELETE') return (await missions.remove(m[1])) ? json(200, { deleted: true }) : json(404, { error: 'not_found' })
    }
    if ((m = /^\/api\/missions\/([^/]+)\/(approve|retry)$/.exec(path)) && method === 'POST') {
      if (!isMissionId(m[1])) throw new MissionError(400, 'bad_id', 'ID misi tidak valid.')
      return json(200, { mission: await (m[2] === 'approve' ? missions.approve(m[1]) : missions.retry(m[1])) })
    }
    if ((m = /^\/api\/missions\/([^/]+)\/artifacts\/([^/]+)$/.exec(path)) && method === 'GET') {
      if (!isMissionId(m[1])) throw new MissionError(400, 'bad_id', 'ID misi tidak valid.')
      const name = decodeURIComponent(m[2])
      const a = await missions.artifactPath(m[1], name)
      if (!a) return json(404, { error: 'not_found' })
      const { readFile } = await import('node:fs/promises')
      return download({ bytes: await readFile(a.path), name: a.artifact.name, mime: a.artifact.mime, inline: false })
    }

    return json(404, { error: 'not_found' })
  }

  async function handle(req) {
    try {
      return await route(req)
    } catch (e) {
      if (e instanceof FileError || e instanceof MissionError) return json(e.status, { error: e.code, message: e.message })
      console.error(`[api] ${req.method} ${String(req.path).split('?')[0]} gagal: ${e?.name || 'Error'}: ${String(e?.message || e).slice(0, 200)}`) // tanpa isi file
      return json(500, { error: 'internal_error', message: 'Terjadi kesalahan internal.' })
    }
  }

  return { handle, files, kb, missions }
}
