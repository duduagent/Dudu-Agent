import { useState, type FormEvent } from 'react'
import { api, type Capabilities } from '../../lib/api'
import { MAX_NOTES, MAX_NOTE_CHARS, loadMemory, saveMemory, type MemoryNote } from '../../lib/memory'
import { useLoad } from '../../lib/useLoad'
import { cx } from '../../lib/util'
import { Icon } from '../ui'
import { STATE_LABEL } from './MissionsPage'
import { PageShell, StateMsg, fmtDate } from './PageShell'

interface PageProps { onToggleLeft: () => void; leftCollapsed: boolean; onActivity?: (m: string) => void }

type Status = 'ok' | 'warn' | 'off'
const statusOf = (configured: boolean): { s: Status; label: string } => configured ? { s: 'warn', label: 'Dikonfigurasi (koneksi belum diuji)' } : { s: 'off', label: 'Belum dikonfigurasi' }

function toolRows(c: Capabilities): Array<{ name: string; desc: string; s: Status; label: string; note?: string }> {
  const chat = statusOf(c.chat.configured), vision = statusOf(c.vision.configured), stt = statusOf(c.stt.configured)
  return [
    { name: 'Ekstraksi dokumen', desc: 'PDF (teks), DOCX, XLSX, PPTX, ODT/ODS/ODP, RTF, HTML, teks/kode/CSV/JSON, daftar isi ZIP', s: 'ok', label: 'Tersedia (lokal)' },
    { name: 'OCR (PDF/gambar pindaian)', desc: 'Membaca teks dari gambar', s: 'off', label: 'Tidak tersedia', note: c.ocr.reason },
    { name: 'Analisis data (data.profile)', desc: 'Parse CSV/TSV/JSON/JSONL/XLSX, profil kolom dan statistik', s: 'ok', label: 'Tersedia (lokal)' },
    { name: 'Penulis laporan (report.write)', desc: 'Menulis artefak report.md dan profile.json dengan hash', s: 'ok', label: 'Tersedia (lokal)' },
    { name: 'Knowledge Base', desc: 'Chunking + indeks persisten + retrieval BM25 dengan sumber', s: 'ok', label: 'Tersedia (kata kunci)', note: c.embeddings.reason },
    { name: 'Provider chat', desc: `Model: ${c.chat.model}`, s: chat.s, label: chat.label, note: c.chat.configured ? 'Status "Terhubung" muncul di chat setelah balasan pertama yang sukses.' : 'Isi DUDU_PROVIDER_API_KEY.' },
    { name: 'Vision (gambar)', desc: c.vision.model ? `Model: ${c.vision.model}` : 'Memahami isi gambar', s: vision.s, label: vision.label, note: c.vision.reason ?? undefined },
    { name: 'Transkripsi audio', desc: c.stt.model ? `Model: ${c.stt.model}` : 'Mengubah audio menjadi teks', s: stt.s, label: stt.label, note: c.stt.reason ?? undefined },
    { name: 'Pemrosesan video', desc: 'Ekstraksi frame + transkripsi audio', s: 'off', label: 'Tidak tersedia', note: c.video.reason },
    { name: 'Embedding semantik', desc: 'Pencarian berdasarkan makna', s: 'off', label: 'Tidak tersedia', note: c.embeddings.reason },
  ]
}
const ToolsTable = ({ c }: { c: Capabilities }) => (
  <ul className="cards" aria-label="Registri tool">
    {toolRows(c).map(r => (
      <li key={r.name} className="card"><div className="card-text"><strong>{r.name}</strong><span className="meta">{r.desc}</span>{r.note && <span className="meta">{r.note}</span>}</div>
        <span className={cx('pill', r.s === 'ok' ? 'ok' : r.s === 'warn' ? 'warn' : '')}>{r.label}</span></li>
    ))}
  </ul>
)

export function ToolsPage({ onToggleLeft, leftCollapsed }: PageProps) {
  const caps = useLoad(api.capabilities)
  return (
    <PageShell title="Tools & Integrations" subtitle="Kemampuan yang benar-benar ada, dengan status sebenarnya." onToggleLeft={onToggleLeft} leftCollapsed={leftCollapsed}>
      <p className="empty-note">"Dikonfigurasi" berarti kunci dan model sudah diatur — <strong>bukan</strong> bukti bahwa layanan eksternal bekerja. Tidak ada integrasi pihak ketiga (email, kalender, repositori, dll.) yang terhubung saat ini.</p>
      <StateMsg loading={caps.loading && !caps.data} error={caps.error} onRetry={caps.reload} />
      {caps.data && <ToolsTable c={caps.data} />}
    </PageShell>
  )
}

export function WorkforcePage({ onToggleLeft, leftCollapsed }: PageProps) {
  const ms = useLoad(api.missions)
  const list = ms.data ?? []
  const count = (s: string) => list.filter(m => m.state === s).length
  return (
    <PageShell title="Agent Workforce" subtitle="Pelaksana yang benar-benar tersedia saat ini." onToggleLeft={onToggleLeft} leftCollapsed={leftCollapsed}>
      <StateMsg loading={ms.loading && !ms.data} error={ms.error} onRetry={ms.reload} />
      <h2 className="sec">Pelaksana aktif</h2>
      <ul className="cards"><li className="card">
        <div className="card-text">
          <strong>Pelaksana Analisis Data (lokal)</strong>
          <span className="meta">Tool: input.validate → data.load → data.profile → report.write → verify.criteria. Berjalan di perangkat ini; tanpa jaringan; menulis hanya ke folder artefak misi.</span>
          <span className="meta">Misi: {list.length} total · {count('completed')} selesai · {count('needs_attention')} {STATE_LABEL.needs_attention.toLowerCase()} · {count('failed')} gagal · {count('draft')} draft</span>
        </div>
        <span className="pill ok">Tersedia</span>
      </li></ul>
      <h2 className="sec">Belum ada</h2>
      <ul className="cards">
        {['Agen otonom berbasis LLM (perencanaan dan pemilihan tool oleh model)', 'Adapter coding-agent eksternal', 'Eksekusi paralel beberapa agen'].map(t => (
          <li key={t} className="card"><div className="card-text"><strong>{t}</strong></div><span className="pill">Belum diimplementasikan</span></li>
        ))}
      </ul>
      <p className="empty-note">Dudu saat ini bukan "tenaga kerja agen otonom". Yang ada: satu pelaksana deterministik dengan persetujuan manusia dan verifikasi independen.</p>
    </PageShell>
  )
}

export function MemoryPage({ onToggleLeft, leftCollapsed, onActivity }: PageProps) {
  const [notes, setNotes] = useState<MemoryNote[]>(loadMemory)
  const [text, setText] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const commit = (next: MemoryNote[]) => { setNotes(next); if (!saveMemory(next)) setErr('Penyimpanan lokal gagal; perubahan belum tentu tersimpan.'); else setErr(null) }

  function add(e: FormEvent) {
    e.preventDefault()
    const t = text.trim()
    if (!t) return
    if (notes.length >= MAX_NOTES) return setErr(`Maksimal ${MAX_NOTES} catatan.`)
    commit([{ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, text: t.slice(0, MAX_NOTE_CHARS), createdAt: Date.now(), enabled: true }, ...notes]); setText(''); onActivity?.('Catatan memori ditambahkan')
  }
  return (
    <PageShell title="Memory" subtitle="Catatan yang Anda tulis sendiri; dikirim ke model sebagai konteks di setiap percakapan." onToggleLeft={onToggleLeft} leftCollapsed={leftCollapsed}>
      <p className="empty-note">Ini <strong>memori eksplisit</strong>: hanya berisi apa yang Anda ketik di sini. Dudu tidak menyimpan memori otomatis dari percakapan. Catatan yang aktif dikirim ke provider model pada setiap pesan; jangan menyimpan rahasia (kata sandi, kunci).</p>
      <form className="row" onSubmit={add}>
        <label className="sr-only" htmlFor="mem-text">Catatan baru</label>
        <input id="mem-text" className="input" value={text} onChange={e => setText(e.target.value)} maxLength={MAX_NOTE_CHARS} placeholder="Mis. Saya lebih suka jawaban singkat dalam poin-poin" />
        <button type="submit" className="btn-primary" disabled={!text.trim()}>Simpan catatan</button>
      </form>
      {err && <p className="state-msg error" role="alert">{err}</p>}
      {notes.length === 0 && <p className="empty-note">Belum ada catatan memori.</p>}
      <ul className="cards">
        {notes.map(n => (
          <li key={n.id} className="card">
            <div className="card-text"><span className={cx(!n.enabled && 'muted')}>{n.text}</span><span className="meta">{fmtDate(n.createdAt)}{n.enabled ? '' : ' · nonaktif'}</span></div>
            <div className="card-actions">
              <button type="button" className="chip-btn" aria-pressed={n.enabled} onClick={() => commit(notes.map(x => (x.id === n.id ? { ...x, enabled: !x.enabled } : x)))}>{n.enabled ? 'Nonaktifkan' : 'Aktifkan'}</button>
              <button type="button" className="chip-btn danger" aria-label={`Hapus catatan: ${n.text.slice(0, 30)}`} onClick={() => { commit(notes.filter(x => x.id !== n.id)); onActivity?.('Catatan memori dihapus') }}><Icon name="trash" size={12} /> Hapus</button>
            </div>
          </li>
        ))}
      </ul>
    </PageShell>
  )
}

export function SettingsPage({ onToggleLeft, leftCollapsed }: PageProps) {
  const caps = useLoad(api.capabilities)
  const desktop = typeof window !== 'undefined' && window.dudu?.isDesktop
  const platform = window.dudu?.platform
  const c = caps.data
  return (
    <PageShell title="Pengaturan" subtitle="Provider, batas, dan lokasi data." onToggleLeft={onToggleLeft} leftCollapsed={leftCollapsed}>
      <StateMsg loading={caps.loading && !caps.data} error={caps.error} onRetry={caps.reload} />
      {c && (<>
        <h2 className="sec">Provider</h2>
        <dl className="kv">
          <dt>Model chat</dt><dd>{c.chat.model} — {statusOf(c.chat.configured).label}</dd>
          <dt>Vision</dt><dd>{c.vision.configured ? `${c.vision.model} — dikonfigurasi (koneksi belum diuji)` : `Belum dikonfigurasi (${c.vision.reason})`}</dd>
          <dt>Transkripsi</dt><dd>{c.stt.configured ? `${c.stt.model} — dikonfigurasi (koneksi belum diuji)` : `Belum dikonfigurasi (${c.stt.reason})`}</dd>
        </dl>
        <p className="meta">Kunci API tidak pernah ditampilkan atau dikirim ke UI. {desktop
          ? 'Ubah lewat menu Dudu AI → Buka folder konfigurasi (dudu.env); berlaku pada pesan berikutnya.'
          : 'Ubah lewat file .env di server development; mulai ulang server setelah mengubah.'}</p>
        <h2 className="sec">Batas</h2>
        <dl className="kv"><dt>Ukuran maksimum file</dt><dd>{Math.round(c.limits.maxUploadBytes / 1048576)} MB (DUDU_MAX_UPLOAD_MB)</dd><dt>Lampiran per pesan</dt><dd>{c.limits.maxAttachments}</dd></dl>
      </>)}
      <h2 className="sec">Data</h2>
      <dl className="kv">
        <dt>Mode</dt><dd>{desktop ? `Aplikasi desktop${platform ? ` (${platform})` : ''}` : 'Web / development'}</dd>
        <dt>Penyimpanan</dt><dd>{desktop ? 'Folder data aplikasi di akun OS Anda (file, indeks, misi, artefak, percakapan, dan dudu.env). Uninstall tidak menghapusnya.' : 'File/KB/misi: folder DUDU_DATA_DIR server; percakapan: localStorage browser.'}</dd>
        <dt>Cloud</dt><dd>Tidak ada. Data hanya keluar dari perangkat saat isi pesan/lampiran dikirim ke provider model yang Anda konfigurasi.</dd>
      </dl>
    </PageShell>
  )
}
