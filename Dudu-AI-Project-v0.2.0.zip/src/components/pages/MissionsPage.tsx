import { useEffect, useState, type FormEvent } from 'react'
import { api, type Mission, type MissionState } from '../../lib/api'
import { useLoad } from '../../lib/useLoad'
import { cx } from '../../lib/util'
import { fmtSize } from '../Attachments'
import { ReminderWorkspace } from '../ReminderWorkspace'
import { Icon } from '../ui'
import { PageShell, StateMsg, fmtDate } from './PageShell'

export const STATE_LABEL: Record<MissionState, string> = { draft: 'Draft', queued: 'Antre', running: 'Berjalan', needs_attention: 'Perlu Perhatian', completed: 'Selesai', failed: 'Gagal' }
const STATE_CLS: Record<MissionState, string> = { draft: '', queued: 'warn', running: 'warn', needs_attention: 'warn', completed: 'ok', failed: 'err' }
const STEP_LABEL = { pending: 'menunggu', running: 'berjalan', done: 'selesai', failed: 'gagal' } as const
const AC_LABEL = { pending: 'belum diperiksa', passed: 'lulus', failed: 'GAGAL' } as const
const TABULAR = new Set(['csv', 'tsv', 'json', 'jsonl', 'ndjson', 'xlsx'])

function MissionDetail({ m, onChanged, onActivity }: { m: Mission; onChanged: (m: Mission) => void; onActivity: (s: string) => void }) {
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function run(kind: 'approve' | 'retry') {
    setBusy(true); setErr(null)
    try {
      const next = await (kind === 'approve' ? api.approveMission(m.id) : api.retryMission(m.id))
      onChanged(next); onActivity(`Misi "${m.title}": ${STATE_LABEL[next.state]}`)
    } catch (e) { setErr(e instanceof Error ? e.message : 'Gagal menjalankan misi.') } finally { setBusy(false) }
  }

  return (
    <article className="mission-detail" aria-label={`Detail misi ${m.title}`}>
      <header>
        <h2>{m.title}</h2>
        <span className={cx('pill', STATE_CLS[m.state])} data-testid="mission-state">{STATE_LABEL[m.state]}</span>
      </header>
      <p className="meta">Sumber: {m.fileName} · dibuat {fmtDate(m.createdAt)} · perencana: {m.planner === 'rule-based' ? 'berbasis aturan (bukan model AI)' : m.planner}</p>

      {m.state === 'draft' && (
        <div className="approval" role="group" aria-label="Persetujuan">
          <p><strong>Menunggu persetujuan Anda.</strong> Eksekusi hanya menulis artefak misi ini ({m.policy.writeScope}); tanpa akses jaringan; tidak ada tindakan destruktif.</p>
          <button type="button" className="btn-primary" disabled={busy} onClick={() => void run('approve')}>{busy ? 'Menjalankan…' : 'Setujui & jalankan'}</button>
        </div>
      )}
      {m.failure && (
        <div className="failure" role="alert">
          <strong>{m.state === 'failed' ? 'Misi gagal' : 'Perlu perhatian'} — {m.failure.class}</strong>
          <p>{m.failure.message}</p>
          {m.failure.retryable
            ? <button type="button" className="btn-primary" disabled={busy} onClick={() => void run('retry')}><Icon name="retry" size={13} /> {busy ? 'Mencoba ulang…' : 'Coba ulang'}</button>
            : <p className="meta">Kegagalan ini tidak dapat dicoba ulang secara otomatis{m.state === 'needs_attention' ? ' — tinjau bukti di bawah' : ''}.</p>}
        </div>
      )}
      {err && <p className="state-msg error" role="alert">{err}</p>}

      <h3>Kriteria penerimaan</h3>
      <ul className="criteria">
        {m.acceptance.map(c => (
          <li key={c.id} className={c.status}>
            <span className={cx('pill', c.status === 'passed' ? 'ok' : c.status === 'failed' ? 'err' : '')}>{AC_LABEL[c.status]}</span>
            <div><span>{c.text}</span>{c.evidence && <span className="meta evidence">Bukti: {c.evidence}</span>}</div>
          </li>
        ))}
      </ul>

      <h3>Langkah eksekusi</h3>
      <ol className="steps">
        {m.steps.map(s => {
          const last = s.attempts[s.attempts.length - 1]
          return (
            <li key={s.id} className={s.status}>
              <span className="step-tool">{s.tool}</span>
              <span>{s.title}</span>
              <span className="meta">{STEP_LABEL[s.status]}{s.attempts.length > 1 ? ` · ${s.attempts.length} percobaan` : ''}
                {last?.execId ? ` · exec ${last.execId.slice(0, 8)}` : ''}{last?.finishedAt ? ` · ${last.finishedAt - last.startedAt} ms` : ''}{last && last.ok === false ? ` · ${last.error}` : ''}</span>
            </li>
          )
        })}
      </ol>

      {m.artifacts.length > 0 && (<>
        <h3>Artefak</h3>
        <ul className="cards">{m.artifacts.map(a => (
          <li key={a.name} className="card"><div className="card-text"><strong>{a.name}</strong><span className="meta">{fmtSize(a.size)} · sha256 {a.sha256.slice(0, 16)}…</span></div>
            <div className="card-actions"><a className="chip-btn" href={api.artifactUrl(m.id, a.name)} download={a.name}><Icon name="download" size={12} /> Unduh</a></div></li>
        ))}</ul>
      </>)}

      <details className="log"><summary>Log eksekusi ({m.log.length})</summary>
        <ul>{m.log.map((l, i) => <li key={i} className={l.level}><time>{new Date(l.at).toLocaleTimeString('id-ID')}</time> {l.msg}</li>)}</ul>
      </details>
    </article>
  )
}

export function MissionsPage({ onToggleLeft, leftCollapsed, onActivity }: { onToggleLeft: () => void; leftCollapsed: boolean; onActivity: (m: string) => void }) {
  const [tab, setTab] = useState<'misi' | 'pengingat'>('misi')
  const missions = useLoad(api.missions)
  const files = useLoad(api.listFiles)
  const [selected, setSelected] = useState<string | null>(null)
  const [goal, setGoal] = useState('')
  const [fileId, setFileId] = useState('')
  const [creating, setCreating] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const list = missions.data ?? []
  const current = list.find(m => m.id === selected) ?? null
  const tabular = (files.data ?? []).filter(f => TABULAR.has(f.ext))
  useEffect(() => { if (!selected && list.length) setSelected(list[0].id) }, [list, selected])

  const replace = (m: Mission) => missions.setData(prev => (prev ? prev.map(x => (x.id === m.id ? m : x)) : [m]))

  async function create(e: FormEvent) {
    e.preventDefault()
    setCreating(true); setErr(null)
    try {
      const m = await api.createMission(goal.trim(), fileId)
      missions.setData(prev => [m, ...(prev ?? [])]); setSelected(m.id); setGoal(''); setFileId(''); onActivity(`Misi dibuat (Draft): ${m.title}`)
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : 'Gagal membuat misi.') } finally { setCreating(false) }
  }
  async function del(m: Mission) {
    if (!window.confirm(`Hapus misi "${m.title}" beserta artefaknya?`)) return
    try { await api.deleteMission(m.id); missions.setData(prev => (prev ?? []).filter(x => x.id !== m.id)); setSelected(null); onActivity(`Misi dihapus: ${m.title}`) }
    catch (e) { setErr(e instanceof Error ? e.message : 'Gagal menghapus misi.') }
  }

  return (
    <PageShell title="Misi & Tugas" subtitle="Tujuan → kriteria penerimaan → persetujuan → eksekusi tool nyata → verifikasi → artefak." onToggleLeft={onToggleLeft} leftCollapsed={leftCollapsed}
      actions={<div className="tabs" role="tablist" aria-label="Bagian">
        {(['misi', 'pengingat'] as const).map(t => (
          <button key={t} type="button" role="tab" id={`tab-${t}`} aria-selected={tab === t} aria-controls={`panel-${t}`} className={cx('tab', tab === t && 'on')} onClick={() => setTab(t)}>{t === 'misi' ? 'Misi' : 'Pengingat'}</button>
        ))}</div>}>
      {tab === 'pengingat' ? (
        <div role="tabpanel" id="panel-pengingat" aria-labelledby="tab-pengingat" className="embedded"><ReminderWorkspace onActivity={onActivity} /></div>
      ) : (
        <div role="tabpanel" id="panel-misi" aria-labelledby="tab-misi">
          <p className="empty-note">Saat ini tersedia satu template: <strong>analisis data tabular</strong> (CSV, TSV, JSON, JSONL, XLSX). Perencanaan berbasis aturan dan eksekusi oleh tool lokal deterministik — bukan agen AI otonom. Setiap kriteria diverifikasi ulang secara independen dari data mentah.</p>
          <form className="mission-form" onSubmit={e => void create(e)}>
            <label htmlFor="m-goal">Tujuan misi</label>
            <textarea id="m-goal" value={goal} onChange={e => setGoal(e.target.value)} rows={2} maxLength={500} placeholder="Mis. Analisis data penjualan dan laporkan kualitas datanya" />
            <div className="row">
              <label className="sr-only" htmlFor="m-file">File sumber</label>
              <select id="m-file" className="select" value={fileId} onChange={e => setFileId(e.target.value)}>
                <option value="">{tabular.length ? 'Pilih file data…' : 'Belum ada file data (unggah di Files & Artifacts)'}</option>
                {tabular.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
              <button type="submit" className="btn-primary" disabled={goal.trim().length < 5 || !fileId || creating}>{creating ? 'Membuat…' : 'Buat misi (Draft)'}</button>
            </div>
            {err && <p className="state-msg error" role="alert">{err}</p>}
          </form>

          <StateMsg loading={missions.loading && !missions.data} error={missions.error} onRetry={missions.reload} />
          {!missions.loading && list.length === 0 && !missions.error && <p className="empty-note">Belum ada misi. Buat misi pertama Anda di atas.</p>}
          {list.length > 0 && (
            <div className="mission-layout">
              <ul className="mission-list" aria-label="Daftar misi">
                {list.map(m => (
                  <li key={m.id}><button type="button" className={cx('mission-item', selected === m.id && 'on')} aria-current={selected === m.id} onClick={() => setSelected(m.id)}>
                    <strong>{m.title}</strong><span className={cx('pill', STATE_CLS[m.state])}>{STATE_LABEL[m.state]}</span>
                  </button></li>
                ))}
              </ul>
              <div>
                {current && <MissionDetail key={current.id + current.updatedAt} m={current} onChanged={replace} onActivity={onActivity} />}
                {current && current.state !== 'running' && <button type="button" className="chip-btn danger del-mission" onClick={() => void del(current)}><Icon name="trash" size={12} /> Hapus misi</button>}
              </div>
            </div>
          )}
        </div>
      )}
    </PageShell>
  )
}
