// Klien API tipis untuk backend lokal (file, Knowledge Base, misi, kapabilitas).
import { unreachableMessage } from './provider'

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message) }
}

export interface Readiness { ready: boolean; reason?: string }
export interface FileMeta {
  id: string; name: string; ext: string; mime: string; category: 'document' | 'image' | 'audio' | 'video' | 'data' | 'archive' | 'code' | 'other'
  kind: string; size: number; sha256: string; createdAt: number
  extraction: { state: 'extracted' | 'unsupported' | 'failed' | 'not_applicable'; method?: string; pages?: number; chars: number; truncated: boolean; note?: string; warnings?: string[] }
  image?: { width: number; height: number }
  readiness: Readiness
}
export interface Capabilities {
  chat: { configured: boolean; model: string }
  vision: { configured: boolean; model: string | null; reason: string | null }
  stt: { configured: boolean; model: string | null; reason: string | null }
  ocr: { available: boolean; reason: string }
  video: { supported: boolean; reason: string }
  embeddings: { configured: boolean; retrieval: string; reason: string }
  limits: { maxUploadBytes: number; maxAttachments: number }
}
export interface KbDoc { fileId: string; name: string; indexedAt: number; chunks: number; missing: boolean }
export interface KbStats { docs: KbDoc[]; chunks: number; retrieval: string; embeddings: boolean }
export interface KbHit { fileId: string; name: string; loc: string | null; score: number; text: string }

export type MissionState = 'draft' | 'queued' | 'running' | 'needs_attention' | 'completed' | 'failed'
export interface MissionStep { id: string; tool: string; title: string; status: 'pending' | 'running' | 'done' | 'failed'; attempts: Array<{ execId: string; startedAt: number; finishedAt?: number; ok?: boolean; error?: string; class?: string; attempt: number }>; output?: unknown }
export interface Mission {
  id: string; title: string; goal: string; template: string; planner: string; fileId: string; fileName: string; state: MissionState; createdAt: number; updatedAt: number
  policy: { requiresApproval: boolean; writeScope: string; network: boolean; destructive: boolean; maxAutoRetries: number }
  approval: { status: 'pending' | 'approved'; at?: number }
  acceptance: Array<{ id: string; text: string; status: 'pending' | 'passed' | 'failed'; evidence?: string; checkedAt?: number }>
  steps: MissionStep[]
  artifacts: Array<{ name: string; size: number; sha256: string; mime: string }>
  failure: { class: string; message: string; retryable: boolean } | null
  log: Array<{ at: number; level: string; msg: string }>
}

async function parseError(res: Response): Promise<ApiError> {
  let code = 'http_error', message = `Permintaan gagal (${res.status}).`
  try { const b = (await res.json()) as { error?: string; message?: string; details?: string }; code = b.error ?? code; message = b.message ?? b.details ?? message } catch { /* bukan JSON */ }
  return new ApiError(res.status, code, message)
}

export async function apiJson<T>(method: 'GET' | 'POST' | 'DELETE', path: string, body?: unknown, signal?: AbortSignal): Promise<T> {
  let res: Response
  try {
    res = await fetch(path, {
      method, signal,
      headers: { ...(method !== 'GET' ? { 'X-Dudu-Client': '1' } : {}), ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e
    throw new ApiError(0, 'unreachable', unreachableMessage())
  }
  if (!res.ok) throw await parseError(res)
  return (await res.json()) as T
}

const isObj = (x: unknown): x is Record<string, unknown> => typeof x === 'object' && x !== null && !Array.isArray(x)
const bad = (what: string) => new ApiError(502, 'bad_response', `Respons ${what} dari server tidak valid.`)

export const api = {
  capabilities: async () => {
    const c = await apiJson<unknown>('GET', '/api/capabilities')
    if (!isObj(c) || !isObj(c.limits) || typeof c.limits.maxAttachments !== 'number' || typeof c.limits.maxUploadBytes !== 'number'
      || !isObj(c.vision) || !isObj(c.stt) || !isObj(c.chat)) throw bad('kapabilitas')
    return c as unknown as Capabilities
  },
  listFiles: async () => {
    const r = await apiJson<unknown>('GET', '/api/files')
    if (!isObj(r) || !Array.isArray(r.files)) throw bad('daftar file')
    return r.files as FileMeta[]
  },
  deleteFile: (id: string) => apiJson<{ deleted: boolean }>('DELETE', `/api/files/${id}`),
  fileText: (id: string) => apiJson<{ text: string | null; totalChars: number; truncated: boolean }>('GET', `/api/files/${id}/text`),
  fileUrl: (id: string, inline = false) => `/api/files/${id}/content${inline ? '?inline=1' : ''}`,
  kb: async () => {
    const k = await apiJson<unknown>('GET', '/api/kb')
    if (!isObj(k) || !Array.isArray(k.docs)) throw bad('Knowledge Base')
    return k as unknown as KbStats
  },
  kbIndex: (fileId: string) => apiJson<{ fileId: string; name: string; chunks: number }>('POST', '/api/kb/docs', { fileId }),
  kbRemove: (fileId: string) => apiJson<{ deleted: boolean }>('DELETE', `/api/kb/docs/${fileId}`),
  kbSearch: async (query: string) => (await apiJson<{ results: KbHit[] }>('POST', '/api/kb/search', { query, limit: 5 })).results,
  missions: async () => {
    const r = await apiJson<unknown>('GET', '/api/missions')
    if (!isObj(r) || !Array.isArray(r.missions)) throw bad('daftar misi')
    return r.missions as Mission[]
  },
  createMission: async (goal: string, fileId: string) => (await apiJson<{ mission: Mission }>('POST', '/api/missions', { goal, fileId })).mission,
  approveMission: async (id: string) => (await apiJson<{ mission: Mission }>('POST', `/api/missions/${id}/approve`)).mission,
  retryMission: async (id: string) => (await apiJson<{ mission: Mission }>('POST', `/api/missions/${id}/retry`)).mission,
  deleteMission: (id: string) => apiJson<{ deleted: boolean }>('DELETE', `/api/missions/${id}`),
  artifactUrl: (id: string, name: string) => `/api/missions/${id}/artifacts/${encodeURIComponent(name)}`,
}

/** Upload dengan progress nyata (XHR) dan pembatalan. Badan = byte mentah; nama dikirim lewat header. */
export function uploadFile(file: File, opts: { onProgress?: (pct: number) => void; signal?: AbortSignal } = {}): Promise<FileMeta> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('POST', '/api/files')
    xhr.setRequestHeader('X-Dudu-Client', '1')
    xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name))
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) opts.onProgress?.(Math.round((e.loaded / e.total) * 100)) }
    xhr.onerror = () => reject(new ApiError(0, 'unreachable', unreachableMessage()))
    xhr.onabort = () => reject(Object.assign(new Error('Upload dibatalkan'), { name: 'AbortError' }))
    xhr.onload = () => {
      let body: { file?: FileMeta; error?: string; message?: string } = {}
      try { body = JSON.parse(xhr.responseText) } catch { /* bukan JSON */ }
      if (xhr.status >= 200 && xhr.status < 300 && body.file) resolve(body.file)
      else reject(new ApiError(xhr.status, body.error ?? 'upload_failed', body.message ?? `Upload gagal (${xhr.status}).`))
    }
    opts.signal?.addEventListener('abort', () => xhr.abort(), { once: true })
    if (opts.signal?.aborted) { xhr.abort(); return }
    xhr.send(file)
  })
}
