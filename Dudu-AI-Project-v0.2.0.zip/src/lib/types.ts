export type Role = 'user' | 'assistant' | 'system'
export type MsgStatus = 'sending' | 'done' | 'error'

/** Status lampiran pada pesan: 'analyzed' HANYA bila isinya benar-benar dikirim ke model dan balasan sukses. */
export interface MsgAttachment {
  fileId: string
  name: string
  category: string
  state: 'sent' | 'analyzed' | 'not_readable'
  reason?: string
}
export interface MsgSource { n: number; fileId: string; name: string; loc?: string | null }

export interface Message {
  id: string
  role: Role
  content: string
  createdAt: number
  status?: MsgStatus
  error?: string
  attachments?: MsgAttachment[]
  sources?: MsgSource[]
}

export interface Conversation {
  id: string
  title: string
  createdAt: number
  updatedAt: number
  messages: Message[]
}

export interface Prefs { leftCollapsed: boolean; rightCollapsed: boolean }
export type ProviderState = 'unknown' | 'ok' | 'unconfigured' | 'error'
export interface ProviderInfo { state: ProviderState; model?: string; detail?: string }
export interface ActivityEvent { id: string; message: string; at: number }
export type ViewId = 'chat' | 'missions' | 'workforce' | 'knowledge' | 'tools' | 'files' | 'memory' | 'settings'
