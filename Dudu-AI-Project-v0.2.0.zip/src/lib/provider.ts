import type { MsgSource, Role } from './types'

export class ProviderNotConfigured extends Error {}

const isDesktop = () => typeof window !== 'undefined' && !!window.dudu?.isDesktop

export const unreachableMessage = () =>
  isDesktop()
    ? 'Layanan API internal Dudu tidak merespons. Tutup lalu buka kembali aplikasi.'
    : 'Server API tidak terjangkau. Jalankan `npm run server`, lalu coba lagi.'

export const unconfiguredMessage = () =>
  isDesktop()
    ? 'Provider model belum dikonfigurasi (butuh DUDU_PROVIDER_API_KEY). Buka menu Dudu AI → Buka folder konfigurasi, isi dudu.env, simpan, lalu klik Coba lagi.'
    : 'Provider model belum dikonfigurasi (butuh DUDU_PROVIDER_API_KEY di server).'

export interface AttachmentReport { id: string; name: string; used: boolean; reason?: string; via?: string; truncated?: boolean }
export interface ProviderReply { content: string; model?: string; attachments?: AttachmentReport[]; sources?: MsgSource[] }
export interface ChatInput { role: Role; content: string; fileIds?: string[] }

export async function sendChat(
  messages: ChatInput[],
  signal?: AbortSignal,
  opts: { useKnowledge?: boolean } = {},
): Promise<ProviderReply> {
  let res: Response
  try {
    res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, ...(opts.useKnowledge ? { useKnowledge: true } : {}) }),
      signal,
    })
  } catch (err) {
    if ((err as Error).name === 'AbortError') throw err
    throw new ProviderNotConfigured(unreachableMessage())
  }
  if (res.status === 501) {
    throw new ProviderNotConfigured(unconfiguredMessage())
  }
  if (!res.ok) {
    let detail = ''
    try {
      const body = (await res.json()) as { details?: unknown; message?: unknown }
      const d = typeof body.details === 'string' ? body.details : typeof body.message === 'string' ? body.message : ''
      detail = d.slice(0, 300)
    } catch { /* badan error bukan JSON */ }
    throw new Error(`Provider merespons ${res.status}${detail ? `: ${detail}` : '.'}`)
  }
  const data = (await res.json()) as { content?: unknown; model?: unknown; attachments?: AttachmentReport[]; sources?: MsgSource[] }
  if (typeof data.content !== 'string') throw new Error('Format respons provider tidak valid.')
  return {
    content: data.content, model: typeof data.model === 'string' ? data.model : undefined,
    attachments: Array.isArray(data.attachments) ? data.attachments : undefined,
    sources: Array.isArray(data.sources) ? data.sources : undefined,
  }
}
